# 推送到 GitHub

当前执行环境**无法直连 GitHub**：`github.com:443` 和 `api.github.com` 均连接超时，且机器上没有 Git、GitHub CLI 或 GitHub 凭据。因此代码无法从这台机器直接推送，需要在有网络的电脑上执行下面的步骤。

项目已经打包为 `zhixing-classroom.zip`，解压后按任一方式操作即可。

## 先创建仓库

在 GitHub 网页点击 **New repository**：

- 填写仓库名，例如 `zhixing-classroom`
- 选择 Public / Private
- **不要**勾选 “Add a README file”、“Add .gitignore”、“Choose a license”
- 创建后复制仓库地址，例如 `https://github.com/yourname/zhixing-classroom.git`

## 方式一：一键脚本（Windows）

1. 安装 [Git for Windows](https://git-scm.com/download/win)
2. 解压 ZIP，在项目根目录打开 PowerShell
3. 配置一次提交身份：

```powershell
git config --global user.name "你的名字"
git config --global user.email "你的邮箱"
```

4. 运行脚本：

```powershell
.\scripts\push-to-github.ps1 -RepoUrl "https://github.com/你的用户名/zhixing-classroom.git"
```

5. 如果弹出登录窗口：
   - 用户名：GitHub 用户名
   - 密码：**Fine-grained PAT**，不是 GitHub 登录密码

## 方式二：手动命令

```bash
git init
git branch -M main
git add .
git commit -m "feat: 知行教室教室课程管理系统"
git remote add origin https://github.com/你的用户名/zhixing-classroom.git
git push -u origin main
```

如果仓库里已经有 README 等文件，先执行：

```bash
git pull --rebase origin main
git push -u origin main
```

## 创建 Fine-grained PAT

1. GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token
2. Repository access 选择 **Only select repositories**，只选目标仓库
3. Permissions → Repository permissions：
   - **Contents: Read and write**（必须）
   - 如果还要让脚本创建仓库，才需要 **Administration: Read and write**
4. 设置较短的有效期，生成后复制到登录窗口的密码处

推送完成后建议立即撤销该 token。

## 本次未提交的内容

以下运行时文件不会进入仓库：

- `data/`：SQLite 数据库和会话密钥
- `__pycache__/`、`*.pyc`
- `.tmp/`、测试临时目录
- `zhixing-classroom.zip`

仓库中的 `.gitignore` 已包含这些规则。
