/* 应用入口：登录、导航外壳与路由。 */

import {
  $,
  $$,
  state,
  icon,
  esc,
  initial,
  ROLE_LABELS,
  api,
  loadMeta,
  confirmDialog,
  toast,
  setButtonLoading,
  closeActiveModal,
} from "./core.js";
import { renderOverviewPage } from "./pages/overview.js";
import { renderBorrowPage, renderMyBookingsPage, renderAdminBookingsPage } from "./pages/booking.js";
import { renderCoursesPage } from "./pages/courses.js";
import { renderClassroomsPage } from "./pages/classrooms.js";
import { renderSchedulePage } from "./pages/schedule.js";

const NAV = {
  student: [
    { id: "overview", label: "教室总览", hint: "实时空闲情况", icon: "grid" },
    { id: "schedule", label: "我的课表", hint: "本周课程安排", icon: "calendar" },
  ],
  teacher: [
    { id: "overview", label: "教室总览", hint: "实时空闲情况", icon: "grid" },
    { id: "borrow", label: "借用教室", hint: "查找并借用空闲教室", icon: "door" },
    { id: "bookings", label: "我的借用", hint: "查看借用记录", icon: "clipboard" },
    { id: "schedule", label: "我的课表", hint: "本周授课安排", icon: "calendar" },
  ],
  admin: [
    { id: "overview", label: "教室总览", hint: "实时空闲情况", icon: "grid" },
    { id: "courses", label: "课程管理", hint: "课程与排课维护", icon: "book" },
    { id: "classrooms", label: "教室管理", hint: "教室档案与状态", icon: "building" },
    { id: "admin-bookings", label: "借用管理", hint: "全校借用记录", icon: "clipboard" },
  ],
};

const PAGE_META = {
  overview: { title: "教室总览", desc: "实时掌握每一间教室的使用状态", kicker: "REAL-TIME CAMPUS" },
  schedule: { title: "我的课表", desc: "按周查看课程与上课地点", kicker: "WEEKLY SCHEDULE" },
  borrow: { title: "借用教室", desc: "按日期与时段查找可用的空闲教室", kicker: "ROOM BOOKING" },
  bookings: { title: "我的借用", desc: "查看、管理已提交的教室借用", kicker: "MY BOOKINGS" },
  courses: { title: "课程管理", desc: "维护课程、教师、教室与上课时间", kicker: "COURSE ADMIN" },
  classrooms: { title: "教室管理", desc: "维护教室档案与开放状态", kicker: "CLASSROOM ADMIN" },
  "admin-bookings": { title: "借用管理", desc: "查看全校教师的教室借用记录", kicker: "BOOKING ADMIN" },
};

const RENDERERS = {
  overview: renderOverviewPage,
  schedule: renderSchedulePage,
  borrow: renderBorrowPage,
  bookings: renderMyBookingsPage,
  courses: renderCoursesPage,
  classrooms: renderClassroomsPage,
  "admin-bookings": renderAdminBookingsPage,
};

function allowedPages() {
  return (NAV[state.user?.role] || []).map((item) => item.id);
}

function pageFromHash() {
  const value = location.hash.replace(/^#\/?/, "").trim();
  return value || "overview";
}

function go(page, replace = false) {
  const target = `#/${page}`;
  if (replace) {
    history.replaceState(null, "", target);
    route();
  } else if (location.hash === target) {
    route();
  } else {
    location.hash = target;
  }
}

function startClock() {
  clearInterval(state.clockTimer);
  const tick = () => {
    const el = $("#live-clock");
    if (!el) return;
    const now = new Date();
    el.innerHTML = `
      <strong>${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}</strong>
      <span>${now.getMonth() + 1}月${now.getDate()}日 · ${["周日", "周一", "周二", "周三", "周四", "周五", "周六"][now.getDay()]}</span>`;
  };
  tick();
  state.clockTimer = setInterval(tick, 1000);
}

function renderShell(page) {
  clearInterval(state.pollTimer);
  state.pollTimer = null;
  const user = state.user;
  const meta = state.meta;
  const nav = NAV[user.role] || [];
  const pageMeta = PAGE_META[page] || PAGE_META.overview;
  const semester = meta?.semester || {};
  const weekText = semester.week > 0 && semester.week <= 30 ? `第 ${semester.week} 教学周` : "假期";
  const navHtml = nav
    .map(
      (item) => `
      <a class="nav-item ${item.id === page ? "is-active" : ""}" href="#/${item.id}" data-nav>
        <span class="nav-icon">${icon(item.icon)}</span>
        <span class="nav-copy"><strong>${item.label}</strong><small>${item.hint}</small></span>
        <span class="nav-arrow">${icon("arrow")}</span>
      </a>`
    )
    .join("");

  $("#app").innerHTML = `
    <div class="app-shell">
      <div class="sidebar-scrim" data-action="close-sidebar"></div>
      <aside class="sidebar" id="sidebar">
        <div class="brand">
          <div class="brand-mark">知</div>
          <div class="brand-copy">
            <strong>知行教室</strong>
            <span>教室课程管理系统</span>
          </div>
        </div>

        <div class="sidebar-term">
          <div class="term-top"><span>当前学期</span><em>${semester.week > 0 && semester.week <= 30 ? `第 ${semester.week} 周` : "假期"}</em></div>
          <strong>${esc(semester.name || "—")}</strong>
          <div class="term-bar"><span style="width:${Math.min(100, Math.max(4, ((semester.week || 0) / 18) * 100))}%"></span></div>
          <small>${weekText} · 共 18 周教学安排</small>
        </div>

        <div class="nav-label">工作台</div>
        <nav class="sidebar-nav">${navHtml}</nav>

        <div class="sidebar-foot">
          <div class="sidebar-tip">
            <span class="tip-icon">${icon("spark")}</span>
            <div><strong>数据实时同步</strong><small>教室状态每 10 秒自动刷新</small></div>
          </div>
          <div class="sidebar-user">
            <div class="avatar">${initial(user.name)}</div>
            <div class="user-copy">
              <strong>${esc(user.name)}</strong>
              <span>${ROLE_LABELS[user.role]} · ${esc(user.identifier || "—")}</span>
            </div>
            <button type="button" class="icon-btn logout-btn" data-action="logout" title="退出登录" aria-label="退出登录">${icon("logout")}</button>
          </div>
        </div>
      </aside>

      <div class="main-shell">
        <header class="topbar">
          <div class="topbar-left">
            <button type="button" class="icon-btn mobile-menu" data-action="toggle-sidebar" aria-label="打开菜单">${icon("grid")}</button>
            <div class="topbar-heading">
              <span>${pageMeta.kicker}</span>
              <h1>${pageMeta.title}</h1>
            </div>
          </div>
          <div class="topbar-right">
            <div class="live-clock" id="live-clock"></div>
            <div class="topbar-role">${ROLE_LABELS[user.role]}端</div>
          </div>
        </header>
        <main class="page-content" id="page-content">
          <div class="page-loading-inline"><span class="spinner"></span>正在载入页面...</div>
        </main>
      </div>
    </div>`;

  $("[data-action='logout']")?.addEventListener("click", logout);
  $("[data-action='toggle-sidebar']")?.addEventListener("click", () => {
    $(".app-shell")?.classList.add("sidebar-open");
  });
  $("[data-action='close-sidebar']")?.addEventListener("click", () => {
    $(".app-shell")?.classList.remove("sidebar-open");
  });
  $$("[data-nav]").forEach((link) => {
    link.addEventListener("click", () => $(".app-shell")?.classList.remove("sidebar-open"));
  });

  document.title = `${pageMeta.title} · 知行教室`;
  startClock();
}

async function route() {
  if (!state.user) {
    renderLoginPage();
    return;
  }
  const pages = allowedPages();
  let page = pageFromHash();
  if (!pages.includes(page)) {
    page = "overview";
    history.replaceState(null, "", "#/overview");
  }
  state.page = page;
  const meta = PAGE_META[page];
  document.title = `${meta.title} · 知行教室`;
  renderShell(page);
  window.scrollTo({ top: 0, behavior: "auto" });

  const content = $("#page-content");
  try {
    await RENDERERS[page](content);
  } catch (error) {
    console.error(error);
    content.innerHTML = `
      <div class="error-state">
        <div class="error-icon">${icon("alert")}</div>
        <h2>页面加载失败</h2>
        <p>${esc(error.message || "请稍后重试")}</p>
        <button type="button" class="btn btn-primary" data-retry>${icon("refresh")}重新加载</button>
      </div>`;
    content.querySelector("[data-retry]")?.addEventListener("click", route);
  }
}

async function logout() {
  const confirmed = await confirmDialog({
    title: "退出登录",
    message: "确定要退出当前账号吗？",
    confirmText: "退出登录",
  });
  if (!confirmed) return;
  try {
    await api("/logout", { method: "POST" });
  } catch {
    /* 即使请求失败也回到登录页。 */
  }
  clearInterval(state.pollTimer);
  clearInterval(state.clockTimer);
  state.user = null;
  state.csrf = null;
  state.meta = null;
  state.overview = null;
  state.filters = null;
  state.borrowFilters = null;
  history.replaceState(null, "", location.pathname);
  renderLoginPage();
}

function renderLoginPage(message = "") {
  clearInterval(state.pollTimer);
  clearInterval(state.clockTimer);
  closeActiveModal();
  $("#modal-root").innerHTML = "";
  document.body.classList.remove("modal-open");
  document.title = "登录 · 知行教室";
  $("#app").innerHTML = `
    <div class="login-page">
      <section class="login-visual">
        <div class="login-visual-bg"></div>
        <div class="login-brand">
          <div class="brand-mark brand-mark-light">知</div>
          <div class="brand-copy">
            <strong>知行教室</strong>
            <span>ZHIXING CLASSROOM</span>
          </div>
        </div>

        <div class="login-copy">
          <span class="eyebrow eyebrow-light">SMART CAMPUS · 2026</span>
          <h1>让每一间教室，<br><em>都被看见。</em></h1>
          <p>面向学生、教师与教务管理者的教室课程协同平台。实时掌握空闲状态，让教学空间调度更简单。</p>
        </div>

        <div class="login-features">
          <div class="login-feature">
            <span>${icon("grid")}</span>
            <div><strong>实时空闲</strong><small>教室状态一目了然</small></div>
          </div>
          <div class="login-feature">
            <span>${icon("door")}</span>
            <div><strong>一键借用</strong><small>教师快速预约空间</small></div>
          </div>
          <div class="login-feature">
            <span>${icon("calendar")}</span>
            <div><strong>课程协同</strong><small>课表与排课统一管理</small></div>
          </div>
        </div>

        <div class="login-showcase" aria-hidden="true">
          <div class="showcase-top">
            <span class="live-dot"></span>
            <span>实时教室状态</span>
            <em>刚刚更新</em>
          </div>
          <div class="showcase-room">
            <div>
              <strong>综合楼 A101</strong>
              <small>多媒体教室 · 120 人</small>
            </div>
            <span class="showcase-status">空闲中</span>
          </div>
          <div class="showcase-timeline">
            <span class="showcase-seg seg-course" style="left:14%;width:12%"></span>
            <span class="showcase-seg seg-free" style="left:26%;width:34%"></span>
            <span class="showcase-seg seg-book" style="left:60%;width:9%"></span>
            <span class="showcase-seg seg-course" style="left:72%;width:16%"></span>
            <i class="showcase-now" style="left:43%"></i>
          </div>
          <div class="showcase-scale"><span>08:00</span><span>15:00</span><span>22:00</span></div>
        </div>

        <div class="login-visual-foot">知行教室 · 教学空间数字化平台</div>
      </section>

      <section class="login-panel">
        <div class="login-card">
          <div class="login-card-head">
            <span class="eyebrow">WELCOME BACK</span>
            <h2>登录你的工作台</h2>
            <p>学生、教师与管理员使用统一入口</p>
          </div>

          ${message ? `<div class="login-alert">${icon("info")}<span>${esc(message)}</span></div>` : ""}
          <div class="login-alert login-alert-error" id="login-error" hidden></div>

          <form id="login-form" class="login-form" novalidate>
            <label class="field">
              <span>账号</span>
              <div class="input-with-icon">
                ${icon("user")}
                <input type="text" name="username" id="login-username" autocomplete="username" placeholder="请输入账号" autofocus>
              </div>
            </label>
            <label class="field">
              <span>密码</span>
              <div class="input-with-icon">
                ${icon("lock")}
                <input type="password" name="password" id="login-password" autocomplete="current-password" placeholder="请输入密码">
                <button type="button" class="password-toggle" id="password-toggle">显示</button>
              </div>
            </label>
            <button type="submit" class="btn btn-primary btn-login" id="login-submit">
              登录系统
              ${icon("arrow")}
            </button>
          </form>

          <div class="login-divider"><span>演示账号 · 一键进入</span></div>
          <div class="demo-grid">
            <button type="button" class="demo-account" data-demo="student">
              <span class="demo-role">学生端</span>
              <strong>student</strong>
              <small>陈晨 · 计算机2301</small>
            </button>
            <button type="button" class="demo-account" data-demo="teacher">
              <span class="demo-role">教师端</span>
              <strong>teacher</strong>
              <small>张伟 · 计算机学院</small>
            </button>
            <button type="button" class="demo-account" data-demo="admin">
              <span class="demo-role">管理员</span>
              <strong>admin</strong>
              <small>周明 · 教务管理</small>
            </button>
          </div>
          <p class="demo-hint">演示账号密码均为 <code>123456</code>，点击卡片可直接登录</p>
        </div>
        <footer class="login-foot">© 2026 知行教室 · 让教学空间更有秩序</footer>
      </section>
    </div>`;

  $("#password-toggle")?.addEventListener("click", () => {
    const input = $("#login-password");
    const button = $("#password-toggle");
    const show = input.type === "password";
    input.type = show ? "text" : "password";
    button.textContent = show ? "隐藏" : "显示";
  });

  $("#login-form")?.addEventListener("submit", (event) => {
    event.preventDefault();
    performLogin($("#login-username").value.trim(), $("#login-password").value, $("#login-submit"));
  });

  $$("[data-demo]").forEach((button) => {
    button.addEventListener("click", () => {
      $("#login-username").value = button.dataset.demo;
      $("#login-password").value = "123456";
      performLogin(button.dataset.demo, "123456", button);
    });
  });
}

async function performLogin(username, password, button) {
  const errorBox = $("#login-error");
  if (errorBox) {
    errorBox.hidden = true;
    errorBox.textContent = "";
  }
  if (!username || !password) {
    if (errorBox) {
      errorBox.hidden = false;
      errorBox.innerHTML = `${icon("alert")}<span>请输入账号和密码</span>`;
    }
    return;
  }
  setButtonLoading(button, true, "登录中...");
  try {
    const response = await fetch("/api/login", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(data.error || "登录失败，请检查账号密码");
    }
    state.user = data.user;
    state.csrf = data.csrf;
    state.meta = data.meta;
    state.filters = null;
    state.borrowFilters = null;
    state.overview = null;
    state.followNow = false;
    toast(`欢迎回来，${data.user.name}`);
    if (location.hash && allowedPages().includes(pageFromHash())) {
      route();
    } else {
      go("overview", true);
    }
  } catch (error) {
    if (errorBox) {
      errorBox.hidden = false;
      errorBox.innerHTML = `${icon("alert")}<span>${esc(error.message)}</span>`;
    }
  } finally {
    setButtonLoading(button, false);
  }
}

async function boot() {
  try {
    const response = await fetch("/api/me", { credentials: "same-origin", headers: { Accept: "application/json" } });
    if (response.ok) {
      const data = await response.json();
      state.user = data.user;
      state.csrf = data.csrf;
      await loadMeta();
      if (!location.hash || !allowedPages().includes(pageFromHash())) {
        history.replaceState(null, "", "#/overview");
      }
      route();
      return;
    }
    renderLoginPage();
  } catch (error) {
    console.error(error);
    renderLoginPage("无法连接服务器，请确认服务已启动");
  }
}

window.addEventListener("hashchange", () => {
  if (state.user) route();
});
window.addEventListener("auth-expired", () => {
  renderLoginPage("登录状态已失效，请重新登录");
});
window.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    $(".app-shell")?.classList.remove("sidebar-open");
  }
});

boot();
