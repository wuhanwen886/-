"""领域服务：认证、教室空闲计算、课程与借用业务规则。"""

from __future__ import annotations

import hashlib
import hmac
import re
import sqlite3
import time
from datetime import date, datetime, timedelta
from typing import Any

import database

WEEKDAY_LABELS = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
WINDOW_START = 8 * 60
WINDOW_END = 22 * 60
BOOKING_DAYS_AHEAD = 90
SESSION_TTL = 7 * 24 * 3600
TIME_RE = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
BUILDING_ORDER = ["综合楼", "教学楼", "信息楼", "图书馆"]
ROOM_ORDER_SQL = (
    "CASE building "
    "WHEN '综合楼' THEN 1 WHEN '教学楼' THEN 2 WHEN '信息楼' THEN 3 "
    "WHEN '图书馆' THEN 4 ELSE 5 END, room_no"
)


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400, details: dict | None = None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.details = details or {}


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------


def now_local() -> datetime:
    return datetime.now()


def parse_date(value: str, field: str = "日期") -> date:
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        raise ApiError(f"{field}格式不正确，应为 YYYY-MM-DD")


def normalize_time(value: str, field: str = "时间") -> str:
    if not isinstance(value, str):
        raise ApiError(f"{field}格式不正确")
    value = value.strip()
    match = TIME_RE.match(value)
    if not match:
        raise ApiError(f"{field}格式不正确，应为 HH:MM")
    return f"{int(match.group(1)):02d}:{match.group(2)}"


def to_minutes(value: str) -> int:
    hour, minute = value.split(":")
    return int(hour) * 60 + int(minute)


def from_minutes(value: int) -> str:
    return f"{value // 60:02d}:{value % 60:02d}"


def overlap(start_a: int, end_a: int, start_b: int, end_b: int) -> bool:
    return start_a < end_b and end_a > start_b


def public_user(row: sqlite3.Row | dict) -> dict:
    return {
        "id": row["id"],
        "username": row["username"],
        "name": row["name"],
        "role": row["role"],
        "identifier": row["identifier"],
        "class_name": row["class_name"],
    }


def require_role(user: dict, *roles: str) -> None:
    if user["role"] not in roles:
        raise ApiError("你没有权限执行此操作", 403)


def _clean_text(value: Any, field: str, max_length: int = 80) -> str:
    if value is None:
        raise ApiError(f"请填写{field}")
    text = str(value).strip()
    if not text:
        raise ApiError(f"请填写{field}")
    if len(text) > max_length:
        raise ApiError(f"{field}不能超过 {max_length} 个字符")
    return text


def _int_value(value: Any, field: str, minimum: int, maximum: int) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        raise ApiError(f"{field}格式不正确")
    if number < minimum or number > maximum:
        raise ApiError(f"{field}应在 {minimum} 到 {maximum} 之间")
    return number


# ---------------------------------------------------------------------------
# 会话与认证
# ---------------------------------------------------------------------------


def authenticate(conn: sqlite3.Connection, username: str, password: str) -> dict:
    username = (username or "").strip()
    if not username or not password:
        raise ApiError("请输入用户名和密码")
    row = conn.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    if not row or not database.verify_password(password, row["salt"], row["password_hash"]):
        raise ApiError("用户名或密码不正确", 401)
    return public_user(row)


def create_session(user_id: int) -> str:
    expires = int(time.time()) + SESSION_TTL
    payload = f"{user_id}.{expires}"
    signature = hmac.new(
        database.get_secret(), payload.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    return f"{payload}.{signature}"


def read_session(conn: sqlite3.Connection, token: str | None) -> tuple[dict | None, str | None]:
    if not token:
        return None, None
    parts = token.split(".")
    if len(parts) != 3:
        return None, None
    user_id, expires, signature = parts
    payload = f"{user_id}.{expires}"
    expected = hmac.new(
        database.get_secret(), payload.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    if not hmac.compare_digest(signature, expected):
        return None, None
    try:
        if int(expires) < int(time.time()):
            return None, None
        uid = int(user_id)
    except ValueError:
        return None, None
    row = conn.execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()
    if not row:
        return None, None
    return public_user(row), token


def csrf_for_session(token: str) -> str:
    return hmac.new(
        database.get_secret(), ("csrf:" + token).encode("utf-8"), hashlib.sha256
    ).hexdigest()[:40]


# ---------------------------------------------------------------------------
# 学期、元数据
# ---------------------------------------------------------------------------


def semester_info(conn: sqlite3.Connection, on_date: date | None = None) -> dict:
    rows = {
        row["key"]: row["value"]
        for row in conn.execute(
            "SELECT key, value FROM settings WHERE key IN ('semester_start', 'semester_name')"
        ).fetchall()
    }
    try:
        start = date.fromisoformat(rows.get("semester_start", ""))
    except ValueError:
        start = database.default_semester_start(date.today())
    monday = start - timedelta(days=start.isoweekday() - 1)
    target = on_date or date.today()
    week = (target - monday).days // 7 + 1 if target >= monday else 0
    return {
        "start": monday.isoformat(),
        "name": rows.get("semester_name") or database.semester_label(monday),
        "week": week,
        "has_courses": 1 <= week <= 30,
    }


def get_meta(conn: sqlite3.Connection) -> dict:
    teachers = [
        {"id": row["id"], "name": row["name"], "identifier": row["identifier"]}
        for row in conn.execute(
            "SELECT id, name, identifier FROM users WHERE role = 'teacher' ORDER BY id"
        ).fetchall()
    ]
    classrooms = [
        _classroom_dict(row)
        for row in conn.execute(
            f"SELECT * FROM classrooms ORDER BY {ROOM_ORDER_SQL}"
        ).fetchall()
    ]
    buildings = list(dict.fromkeys(row["building"] for row in classrooms))
    room_types = sorted({row["room_type"] for row in classrooms})
    now = now_local()
    return {
        "teachers": teachers,
        "classrooms": classrooms,
        "buildings": buildings,
        "room_types": room_types,
        "semester": semester_info(conn),
        "today": now.date().isoformat(),
        "server_time": now.strftime("%Y-%m-%d %H:%M:%S"),
        "window": {"start": "08:00", "end": "22:00"},
    }


def _classroom_dict(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "name": row["name"],
        "building": row["building"],
        "room_no": row["room_no"],
        "capacity": row["capacity"],
        "room_type": row["room_type"],
        "equipment": [item for item in (row["equipment"] or "").split(",") if item],
        "status": row["status"],
    }


# ---------------------------------------------------------------------------
# 空闲计算
# ---------------------------------------------------------------------------


def _course_intervals(
    conn: sqlite3.Connection, target: date, week: int, classroom_id: int | None = None
) -> list[dict]:
    if week < 1:
        return []
    sql = (
        "SELECT c.*, u.name AS teacher_name FROM courses c "
        "JOIN users u ON u.id = c.teacher_id "
        "WHERE c.weekday = ? AND c.weeks_start <= ? AND c.weeks_end >= ?"
    )
    params: list[Any] = [target.isoweekday(), week, week]
    if classroom_id is not None:
        sql += " AND c.classroom_id = ?"
        params.append(classroom_id)
    return [
        {
            "kind": "course",
            "title": row["name"],
            "subtitle": f"{row['teacher_name']} · {row['class_name']}",
            "teacher": row["teacher_name"],
            "start": row["start_time"],
            "end": row["end_time"],
            "start_min": to_minutes(row["start_time"]),
            "end_min": to_minutes(row["end_time"]),
            "course_id": row["id"],
        }
        for row in conn.execute(sql, params).fetchall()
    ]


def _booking_intervals(
    conn: sqlite3.Connection, target: date, classroom_id: int | None = None
) -> list[dict]:
    sql = (
        "SELECT b.*, u.name AS teacher_name FROM bookings b "
        "JOIN users u ON u.id = b.teacher_id "
        "WHERE b.date = ? AND b.status = 'active'"
    )
    params: list[Any] = [target.isoformat()]
    if classroom_id is not None:
        sql += " AND b.classroom_id = ?"
        params.append(classroom_id)
    return [
        {
            "kind": "booking",
            "title": row["purpose"],
            "subtitle": f"教师借用 · {row['teacher_name']}",
            "teacher": row["teacher_name"],
            "start": row["start_time"],
            "end": row["end_time"],
            "start_min": to_minutes(row["start_time"]),
            "end_min": to_minutes(row["end_time"]),
            "booking_id": row["id"],
        }
        for row in conn.execute(sql, params).fetchall()
    ]


def _intervals_for_date(conn: sqlite3.Connection, target: date) -> dict[int, list[dict]]:
    week = semester_info(conn, target)["week"]
    grouped: dict[int, list[dict]] = {}
    if week >= 1:
        for row in conn.execute(
            "SELECT c.*, u.name AS teacher_name FROM courses c "
            "JOIN users u ON u.id = c.teacher_id "
            "WHERE c.weekday = ? AND c.weeks_start <= ? AND c.weeks_end >= ?",
            (target.isoweekday(), week, week),
        ).fetchall():
            grouped.setdefault(row["classroom_id"], []).append(
                {
                    "kind": "course",
                    "title": row["name"],
                    "subtitle": f"{row['teacher_name']} · {row['class_name']}",
                    "teacher": row["teacher_name"],
                    "start": row["start_time"],
                    "end": row["end_time"],
                    "start_min": to_minutes(row["start_time"]),
                    "end_min": to_minutes(row["end_time"]),
                    "course_id": row["id"],
                }
            )
    for row in conn.execute(
        "SELECT b.*, u.name AS teacher_name FROM bookings b "
        "JOIN users u ON u.id = b.teacher_id "
        "WHERE b.date = ? AND b.status = 'active'",
        (target.isoformat(),),
    ).fetchall():
        grouped.setdefault(row["classroom_id"], []).append(
            {
                "kind": "booking",
                "title": row["purpose"],
                "subtitle": f"教师借用 · {row['teacher_name']}",
                "teacher": row["teacher_name"],
                "start": row["start_time"],
                "end": row["end_time"],
                "start_min": to_minutes(row["start_time"]),
                "end_min": to_minutes(row["end_time"]),
                "booking_id": row["id"],
            }
        )
    for items in grouped.values():
        items.sort(key=lambda item: item["start_min"])
    return grouped


def _teacher_intervals_for_date(
    conn: sqlite3.Connection, teacher_id: int, target: date
) -> list[dict]:
    week = semester_info(conn, target)["week"]
    intervals: list[dict] = []
    if week >= 1:
        for row in conn.execute(
            "SELECT c.*, r.name AS classroom_name FROM courses c "
            "JOIN classrooms r ON r.id = c.classroom_id "
            "WHERE c.teacher_id = ? AND c.weekday = ? AND c.weeks_start <= ? AND c.weeks_end >= ?",
            (teacher_id, target.isoweekday(), week, week),
        ).fetchall():
            intervals.append(
                {
                    "kind": "course",
                    "title": row["name"],
                    "subtitle": f"{row['classroom_name']} · {row['class_name']}",
                    "start": row["start_time"],
                    "end": row["end_time"],
                    "start_min": to_minutes(row["start_time"]),
                    "end_min": to_minutes(row["end_time"]),
                }
            )
    for row in conn.execute(
        "SELECT b.*, r.name AS classroom_name FROM bookings b "
        "JOIN classrooms r ON r.id = b.classroom_id "
        "WHERE b.teacher_id = ? AND b.date = ? AND b.status = 'active'",
        (teacher_id, target.isoformat()),
    ).fetchall():
        intervals.append(
            {
                "kind": "booking",
                "title": row["purpose"],
                "subtitle": f"已借用 {row['classroom_name']}",
                "start": row["start_time"],
                "end": row["end_time"],
                "start_min": to_minutes(row["start_time"]),
                "end_min": to_minutes(row["end_time"]),
            }
        )
    intervals.sort(key=lambda item: item["start_min"])
    return intervals


def get_overview(
    conn: sqlite3.Connection,
    date_value: str | None,
    at_value: str | None,
    user: dict | None = None,
) -> dict:
    target = parse_date(date_value, "查询日期") if date_value else date.today()
    if at_value:
        at = normalize_time(at_value, "查询时间")
    else:
        at = now_local().strftime("%H:%M")
    at_min = to_minutes(at)
    outside_window = at_min < WINDOW_START or at_min >= WINDOW_END
    week = semester_info(conn, target)["week"]
    grouped = _intervals_for_date(conn, target)

    classrooms = []
    for row in conn.execute(
        f"SELECT * FROM classrooms ORDER BY {ROOM_ORDER_SQL}"
    ).fetchall():
        room = _classroom_dict(row)
        intervals = grouped.get(row["id"], [])
        current = next(
            (item for item in intervals if item["start_min"] <= at_min < item["end_min"]), None
        )
        upcoming = next((item for item in intervals if item["start_min"] > at_min), None)
        if row["status"] == "maintenance":
            state = "maintenance"
        elif current:
            state = "busy"
        else:
            state = "free"
        room.update(
            {
                "intervals": intervals,
                "state": state,
                "current": current,
                "upcoming": upcoming,
                "free_until": (
                    from_minutes(upcoming["start_min"])
                    if state == "free" and upcoming
                    else ("22:00" if state == "free" else None)
                ),
            }
        )
        classrooms.append(room)

    active_rooms = [room for room in classrooms if room["status"] == "active"]
    stats = {
        "total": len(active_rooms),
        "free": sum(1 for room in active_rooms if room["state"] == "free"),
        "busy": sum(1 for room in active_rooms if room["state"] == "busy"),
        "maintenance": sum(1 for room in classrooms if room["status"] == "maintenance"),
        "bookings_today": conn.execute(
            "SELECT COUNT(*) FROM bookings WHERE date = ? AND status = 'active'",
            (date.today().isoformat(),),
        ).fetchone()[0],
    }

    now = now_local()
    semester = semester_info(conn, target)
    return {
        "date": target.isoformat(),
        "at": at,
        "week": week,
        "semester": semester,
        "outside_window": outside_window,
        "window": {"start": "08:00", "end": "22:00"},
        "today": date.today().isoformat(),
        "server_time": now.strftime("%Y-%m-%d %H:%M:%S"),
        "classrooms": classrooms,
        "stats": stats,
        "teacher_intervals": (
            _teacher_intervals_for_date(conn, user["id"], target)
            if user and user["role"] == "teacher"
            else []
        ),
    }


# ---------------------------------------------------------------------------
# 课程
# ---------------------------------------------------------------------------


def _course_dict(row: sqlite3.Row) -> dict:
    return {
        "id": row["id"],
        "code": row["code"],
        "name": row["name"],
        "teacher_id": row["teacher_id"],
        "teacher_name": row["teacher_name"],
        "classroom_id": row["classroom_id"],
        "classroom_name": row["classroom_name"],
        "class_name": row["class_name"],
        "weekday": row["weekday"],
        "weekday_label": WEEKDAY_LABELS[row["weekday"] - 1],
        "start_time": row["start_time"],
        "end_time": row["end_time"],
        "weeks_start": row["weeks_start"],
        "weeks_end": row["weeks_end"],
        "weeks_label": f"{row['weeks_start']}-{row['weeks_end']} 周",
    }


COURSE_SELECT = (
    "SELECT c.*, u.name AS teacher_name, r.name AS classroom_name "
    "FROM courses c JOIN users u ON u.id = c.teacher_id "
    "JOIN classrooms r ON r.id = c.classroom_id "
)


def list_courses(conn: sqlite3.Connection, user: dict) -> list[dict]:
    sql = COURSE_SELECT
    params: list[Any] = []
    if user["role"] == "teacher":
        sql += "WHERE c.teacher_id = ? "
        params.append(user["id"])
    elif user["role"] == "student":
        sql += "WHERE c.class_name = ? "
        params.append(user["class_name"] or "")
    sql += "ORDER BY c.weekday, c.start_time, c.name"
    return [_course_dict(row) for row in conn.execute(sql, params).fetchall()]


def _course_dates(conn: sqlite3.Connection, weekday: int, weeks_start: int, weeks_end: int) -> list[str]:
    semester = semester_info(conn)
    monday = date.fromisoformat(semester["start"])
    dates = []
    for week in range(weeks_start, weeks_end + 1):
        d = monday + timedelta(days=(week - 1) * 7 + weekday - 1)
        dates.append(d.isoformat())
    return dates


def _course_booking_conflicts(
    conn: sqlite3.Connection,
    weekday: int,
    weeks_start: int,
    weeks_end: int,
    start_min: int,
    end_min: int,
    classroom_id: int,
    teacher_id: int,
    exclude_id: int | None = None,
) -> str | None:
    dates = _course_dates(conn, weekday, weeks_start, weeks_end)
    if not dates:
        return None
    placeholders = ",".join("?" for _ in dates)
    rows = conn.execute(
        f"SELECT b.*, u.name AS teacher_name, r.name AS classroom_name FROM bookings b "
        f"JOIN users u ON u.id = b.teacher_id JOIN classrooms r ON r.id = b.classroom_id "
        f"WHERE b.status = 'active' AND b.date IN ({placeholders}) "
        f"AND (b.classroom_id = ? OR b.teacher_id = ?)",
        (*dates, classroom_id, teacher_id),
    ).fetchall()
    for row in rows:
        if not overlap(start_min, end_min, to_minutes(row["start_time"]), to_minutes(row["end_time"])):
            continue
        if row["classroom_id"] == classroom_id:
            return (
                f"{row['date']} {row['start_time']}-{row['end_time']}，"
                f"{row['classroom_name']} 已被 {row['teacher_name']} 借用"
            )
        return (
            f"{row['date']} {row['start_time']}-{row['end_time']}，"
            f"{row['teacher_name']} 老师已有教室借用"
        )
    return None


def _validate_course_payload(
    conn: sqlite3.Connection, payload: dict, exclude_id: int | None = None
) -> dict:
    code = _clean_text(payload.get("code"), "课程代码", 24)
    name = _clean_text(payload.get("name"), "课程名称", 60)
    class_name = _clean_text(payload.get("class_name"), "授课班级", 40)
    teacher_id = _int_value(payload.get("teacher_id"), "授课教师", 1, 10**9)
    classroom_id = _int_value(payload.get("classroom_id"), "教室", 1, 10**9)
    weekday = _int_value(payload.get("weekday"), "星期", 1, 7)
    start = normalize_time(payload.get("start_time", ""), "开始时间")
    end = normalize_time(payload.get("end_time", ""), "结束时间")
    weeks_start = _int_value(payload.get("weeks_start"), "起始周", 1, 30)
    weeks_end = _int_value(payload.get("weeks_end"), "结束周", 1, 30)

    start_min, end_min = to_minutes(start), to_minutes(end)
    if end_min <= start_min:
        raise ApiError("结束时间必须晚于开始时间")
    if start_min < WINDOW_START or end_min > WINDOW_END:
        raise ApiError("课程时间需在 08:00-22:00 之间")
    if weeks_end < weeks_start:
        raise ApiError("结束周不能早于起始周")

    teacher = conn.execute(
        "SELECT id, name, role FROM users WHERE id = ?", (teacher_id,)
    ).fetchone()
    if not teacher or teacher["role"] != "teacher":
        raise ApiError("授课教师不存在")
    room = conn.execute("SELECT * FROM classrooms WHERE id = ?", (classroom_id,)).fetchone()
    if not room:
        raise ApiError("教室不存在")

    rows = conn.execute(
        "SELECT c.*, u.name AS teacher_name, r.name AS classroom_name FROM courses c "
        "JOIN users u ON u.id = c.teacher_id JOIN classrooms r ON r.id = c.classroom_id "
        "WHERE c.weekday = ? AND c.id != ?",
        (weekday, exclude_id or 0),
    ).fetchall()
    for row in rows:
        if row["weeks_end"] < weeks_start or row["weeks_start"] > weeks_end:
            continue
        if not overlap(start_min, end_min, to_minutes(row["start_time"]), to_minutes(row["end_time"])):
            continue
        if row["classroom_id"] == classroom_id:
            raise ApiError(
                f"教室冲突：{row['classroom_name']} 在{WEEKDAY_LABELS[weekday - 1]} "
                f"{row['start_time']}-{row['end_time']} 已安排《{row['name']}》"
            )
        if row["teacher_id"] == teacher_id:
            raise ApiError(
                f"教师冲突：{row['teacher_name']} 在{WEEKDAY_LABELS[weekday - 1]} "
                f"{row['start_time']}-{row['end_time']} 已安排《{row['name']}》"
            )
        if (row["class_name"] or "").strip().lower() == class_name.lower():
            raise ApiError(
                f"班级冲突：{class_name} 在{WEEKDAY_LABELS[weekday - 1]} "
                f"{row['start_time']}-{row['end_time']} 已安排《{row['name']}》"
            )

    booking_conflict = _course_booking_conflicts(
        conn,
        weekday,
        weeks_start,
        weeks_end,
        start_min,
        end_min,
        classroom_id,
        teacher_id,
        exclude_id,
    )
    if booking_conflict:
        raise ApiError(f"借用冲突：{booking_conflict}")

    return {
        "code": code,
        "name": name,
        "teacher_id": teacher_id,
        "classroom_id": classroom_id,
        "class_name": class_name,
        "weekday": weekday,
        "start_time": start,
        "end_time": end,
        "weeks_start": weeks_start,
        "weeks_end": weeks_end,
    }


def create_course(conn: sqlite3.Connection, user: dict, payload: dict) -> dict:
    require_role(user, "admin")
    values = _validate_course_payload(conn, payload)
    cur = conn.execute(
        "INSERT INTO courses "
        "(code, name, teacher_id, classroom_id, class_name, weekday, start_time, end_time, weeks_start, weeks_end) "
        "VALUES (:code, :name, :teacher_id, :classroom_id, :class_name, :weekday, :start_time, :end_time, :weeks_start, :weeks_end)",
        values,
    )
    conn.commit()
    row = conn.execute(COURSE_SELECT + "WHERE c.id = ?", (cur.lastrowid,)).fetchone()
    return _course_dict(row)


def update_course(conn: sqlite3.Connection, user: dict, course_id: int, payload: dict) -> dict:
    require_role(user, "admin")
    existing = conn.execute("SELECT id FROM courses WHERE id = ?", (course_id,)).fetchone()
    if not existing:
        raise ApiError("课程不存在", 404)
    values = _validate_course_payload(conn, payload, exclude_id=course_id)
    conn.execute(
        "UPDATE courses SET code = :code, name = :name, teacher_id = :teacher_id, "
        "classroom_id = :classroom_id, class_name = :class_name, weekday = :weekday, "
        "start_time = :start_time, end_time = :end_time, weeks_start = :weeks_start, "
        "weeks_end = :weeks_end WHERE id = :id",
        {**values, "id": course_id},
    )
    conn.commit()
    row = conn.execute(COURSE_SELECT + "WHERE c.id = ?", (course_id,)).fetchone()
    return _course_dict(row)


def delete_course(conn: sqlite3.Connection, user: dict, course_id: int) -> None:
    require_role(user, "admin")
    existing = conn.execute("SELECT id FROM courses WHERE id = ?", (course_id,)).fetchone()
    if not existing:
        raise ApiError("课程不存在", 404)
    conn.execute("DELETE FROM courses WHERE id = ?", (course_id,))
    conn.commit()


def get_schedule(conn: sqlite3.Connection, user: dict) -> dict:
    courses = list_courses(conn, user)
    semester = semester_info(conn)
    week = semester["week"]
    if 1 <= week <= 30:
        courses = [
            course for course in courses if course["weeks_start"] <= week <= course["weeks_end"]
        ]
    else:
        courses = []
    monday = date.fromisoformat(semester["start"]) + timedelta(days=(max(week, 1) - 1) * 7)
    today = date.today()
    days = []
    for index in range(1, 8):
        d = monday + timedelta(days=index - 1)
        days.append(
            {
                "weekday": index,
                "label": WEEKDAY_LABELS[index - 1],
                "date": d.isoformat(),
                "day": d.day,
                "month": d.month,
                "is_today": d == today,
            }
        )
    today_courses = [c for c in courses if c["weekday"] == today.isoweekday()]
    total_minutes = sum(to_minutes(c["end_time"]) - to_minutes(c["start_time"]) for c in courses)
    return {
        "courses": courses,
        "semester": semester,
        "days": days,
        "today": today.isoformat(),
        "stats": {
            "course_count": len(courses),
            "today_count": len(today_courses),
            "weekly_hours": round(total_minutes / 60, 1),
        },
    }


# ---------------------------------------------------------------------------
# 借用
# ---------------------------------------------------------------------------


def _booking_dict(row: sqlite3.Row) -> dict:
    start_min = to_minutes(row["start_time"])
    end_min = to_minutes(row["end_time"])
    today = date.today()
    booking_date = date.fromisoformat(row["date"])
    if row["status"] == "cancelled":
        state = "cancelled"
    elif booking_date < today or (booking_date == today and end_min <= now_local().hour * 60 + now_local().minute):
        state = "ended"
    else:
        state = "active"
    return {
        "id": row["id"],
        "classroom_id": row["classroom_id"],
        "classroom_name": row["classroom_name"],
        "building": row["building"],
        "teacher_id": row["teacher_id"],
        "teacher_name": row["teacher_name"],
        "date": row["date"],
        "start_time": row["start_time"],
        "end_time": row["end_time"],
        "purpose": row["purpose"],
        "status": row["status"],
        "state": state,
        "created_at": row["created_at"],
    }


BOOKING_SELECT = (
    "SELECT b.*, r.name AS classroom_name, r.building, u.name AS teacher_name "
    "FROM bookings b JOIN classrooms r ON r.id = b.classroom_id "
    "JOIN users u ON u.id = b.teacher_id "
)


def list_bookings(conn: sqlite3.Connection, user: dict) -> list[dict]:
    require_role(user, "teacher", "admin")
    sql = BOOKING_SELECT
    params: list[Any] = []
    if user["role"] == "teacher":
        sql += "WHERE b.teacher_id = ? "
        params.append(user["id"])
    sql += "ORDER BY b.date DESC, b.start_time DESC"
    return [_booking_dict(row) for row in conn.execute(sql, params).fetchall()]


def _teacher_booking_conflict(
    conn: sqlite3.Connection,
    teacher_id: int,
    target: date,
    start_min: int,
    end_min: int,
) -> str | None:
    week = semester_info(conn, target)["week"]
    if week >= 1:
        for row in conn.execute(
            "SELECT c.*, r.name AS classroom_name FROM courses c "
            "JOIN classrooms r ON r.id = c.classroom_id "
            "WHERE c.teacher_id = ? AND c.weekday = ? AND c.weeks_start <= ? AND c.weeks_end >= ?",
            (teacher_id, target.isoweekday(), week, week),
        ).fetchall():
            if overlap(start_min, end_min, to_minutes(row["start_time"]), to_minutes(row["end_time"])):
                return (
                    f"你在该时段已有课程《{row['name']}》"
                    f"（{row['start_time']}-{row['end_time']}，{row['classroom_name']}）"
                )
    for row in conn.execute(
        "SELECT b.*, r.name AS classroom_name FROM bookings b "
        "JOIN classrooms r ON r.id = b.classroom_id "
        "WHERE b.teacher_id = ? AND b.date = ? AND b.status = 'active'",
        (teacher_id, target.isoformat()),
    ).fetchall():
        if overlap(start_min, end_min, to_minutes(row["start_time"]), to_minutes(row["end_time"])):
            return (
                f"你在该时段已借用 {row['classroom_name']} "
                f"（{row['start_time']}-{row['end_time']}）"
            )
    return None


def create_booking(conn: sqlite3.Connection, user: dict, payload: dict) -> dict:
    require_role(user, "teacher")
    room_id = _int_value(payload.get("classroom_id"), "教室", 1, 10**9)
    target = parse_date(payload.get("date", ""), "借用日期")
    start = normalize_time(payload.get("start_time", ""), "开始时间")
    end = normalize_time(payload.get("end_time", ""), "结束时间")
    purpose = _clean_text(payload.get("purpose"), "借用用途", 100)
    start_min, end_min = to_minutes(start), to_minutes(end)

    today = date.today()
    if target < today:
        raise ApiError("不能借用过去的日期")
    if target > today + timedelta(days=BOOKING_DAYS_AHEAD):
        raise ApiError(f"最多只能提前 {BOOKING_DAYS_AHEAD} 天借用")
    if target == today:
        now = now_local()
        if end_min <= now.hour * 60 + now.minute:
            raise ApiError("该时段已经结束，请选择稍后的时间")
    if end_min <= start_min:
        raise ApiError("结束时间必须晚于开始时间")
    if start_min < WINDOW_START or end_min > WINDOW_END:
        raise ApiError("借用时间需在 08:00-22:00 之间")

    room = conn.execute("SELECT * FROM classrooms WHERE id = ?", (room_id,)).fetchone()
    if not room:
        raise ApiError("教室不存在")
    if room["status"] != "active":
        raise ApiError("该教室正在维护中，暂不可借用")

    week = semester_info(conn, target)["week"]
    for course in _course_intervals(conn, target, week, classroom_id=room_id):
        if overlap(start_min, end_min, course["start_min"], course["end_min"]):
            raise ApiError(
                f"时间冲突：{course['title']} {course['start']}-{course['end']} "
                f"正在该教室上课"
            )
    for booking in _booking_intervals(conn, target, classroom_id=room_id):
        if overlap(start_min, end_min, booking["start_min"], booking["end_min"]):
            raise ApiError(
                f"时间冲突：该教室 {booking['start']}-{booking['end']} "
                f"已被 {booking['teacher']} 借用"
            )
    teacher_conflict = _teacher_booking_conflict(conn, user["id"], target, start_min, end_min)
    if teacher_conflict:
        raise ApiError(f"时间冲突：{teacher_conflict}")

    cur = conn.execute(
        "INSERT INTO bookings (classroom_id, teacher_id, date, start_time, end_time, purpose, status) "
        "VALUES (?, ?, ?, ?, ?, ?, 'active')",
        (room_id, user["id"], target.isoformat(), start, end, purpose),
    )
    conn.commit()
    row = conn.execute(BOOKING_SELECT + "WHERE b.id = ?", (cur.lastrowid,)).fetchone()
    return _booking_dict(row)


def cancel_booking(conn: sqlite3.Connection, user: dict, booking_id: int) -> dict:
    require_role(user, "teacher", "admin")
    row = conn.execute(BOOKING_SELECT + "WHERE b.id = ?", (booking_id,)).fetchone()
    if not row:
        raise ApiError("借用记录不存在", 404)
    if user["role"] == "teacher" and row["teacher_id"] != user["id"]:
        raise ApiError("只能取消自己的借用", 403)
    if row["status"] == "cancelled":
        raise ApiError("该借用已取消")
    booking_date = date.fromisoformat(row["date"])
    now = now_local()
    if booking_date < now.date() or (
        booking_date == now.date()
        and to_minutes(row["end_time"]) <= now.hour * 60 + now.minute
    ):
        raise ApiError("该借用已结束，无法取消")
    conn.execute(
        "UPDATE bookings SET status = 'cancelled', cancelled_at = CURRENT_TIMESTAMP WHERE id = ?",
        (booking_id,),
    )
    conn.commit()
    updated = conn.execute(BOOKING_SELECT + "WHERE b.id = ?", (booking_id,)).fetchone()
    return _booking_dict(updated)


# ---------------------------------------------------------------------------
# 教室与设置
# ---------------------------------------------------------------------------


def _validate_classroom(conn: sqlite3.Connection, payload: dict, exclude_id: int | None = None) -> dict:
    name = _clean_text(payload.get("name"), "教室名称", 40)
    building = _clean_text(payload.get("building"), "所属楼栋", 30)
    room_no = _clean_text(payload.get("room_no"), "房间号", 20)
    capacity = _int_value(payload.get("capacity"), "容纳人数", 1, 2000)
    room_type = _clean_text(payload.get("room_type"), "教室类型", 30)
    equipment = str(payload.get("equipment") or "").strip()
    if len(equipment) > 200:
        raise ApiError("设备说明不能超过 200 个字符")
    status = payload.get("status") or "active"
    if status not in ("active", "maintenance"):
        raise ApiError("教室状态不正确")
    duplicate = conn.execute(
        "SELECT id FROM classrooms WHERE (name = ? OR (building = ? AND room_no = ?)) AND id != ?",
        (name, building, room_no, exclude_id or 0),
    ).fetchone()
    if duplicate:
        raise ApiError("教室名称或楼栋房间号已存在")
    return {
        "name": name,
        "building": building,
        "room_no": room_no,
        "capacity": capacity,
        "room_type": room_type,
        "equipment": equipment,
        "status": status,
    }


def create_classroom(conn: sqlite3.Connection, user: dict, payload: dict) -> dict:
    require_role(user, "admin")
    values = _validate_classroom(conn, payload)
    cur = conn.execute(
        "INSERT INTO classrooms (name, building, room_no, capacity, room_type, equipment, status) "
        "VALUES (:name, :building, :room_no, :capacity, :room_type, :equipment, :status)",
        values,
    )
    conn.commit()
    row = conn.execute("SELECT * FROM classrooms WHERE id = ?", (cur.lastrowid,)).fetchone()
    return _classroom_dict(row)


def update_classroom(conn: sqlite3.Connection, user: dict, room_id: int, payload: dict) -> dict:
    require_role(user, "admin")
    existing = conn.execute("SELECT id FROM classrooms WHERE id = ?", (room_id,)).fetchone()
    if not existing:
        raise ApiError("教室不存在", 404)
    values = _validate_classroom(conn, payload, exclude_id=room_id)
    conn.execute(
        "UPDATE classrooms SET name = :name, building = :building, room_no = :room_no, "
        "capacity = :capacity, room_type = :room_type, equipment = :equipment, status = :status "
        "WHERE id = :id",
        {**values, "id": room_id},
    )
    conn.commit()
    row = conn.execute("SELECT * FROM classrooms WHERE id = ?", (room_id,)).fetchone()
    return _classroom_dict(row)


def list_classrooms(conn: sqlite3.Connection, user: dict) -> list[dict]:
    return [
        _classroom_dict(row)
        for row in conn.execute(
            f"SELECT * FROM classrooms ORDER BY {ROOM_ORDER_SQL}"
        ).fetchall()
    ]


def update_semester(conn: sqlite3.Connection, user: dict, payload: dict) -> dict:
    require_role(user, "admin")
    start = parse_date(payload.get("start", ""), "学期开始日期")
    name = _clean_text(payload.get("name"), "学期名称", 60)
    monday = start - timedelta(days=start.isoweekday() - 1)
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('semester_start', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (monday.isoformat(),),
    )
    conn.execute(
        "INSERT INTO settings (key, value) VALUES ('semester_name', ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (name,),
    )
    conn.commit()
    return semester_info(conn)
