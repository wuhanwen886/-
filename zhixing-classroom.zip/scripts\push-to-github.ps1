param(
    [Parameter(Mandatory = $true)]
    [string]$RepoUrl,

    [string]$Branch = "main",

    [string]$CommitMessage = "feat: 知行教室教室课程管理系统"
)

$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    throw "未找到 Git。请先安装 Git for Windows：https://git-scm.com/download/win"
}
if (-not (Get-Command git).Source) {
    throw "Git 不可用。"
}

$name = git config --get user.name
$email = git config --get user.email
if (-not $name -or -not $email) {
    throw "请先配置提交身份：`n  git config --global user.name `"你的名字`"`n  git config --global user.email `"你的邮箱`""
}

if (-not (Test-Path ".git")) {
    git init -b $Branch
}

git add -A
$changes = git status --porcelain
if ($changes) {
    git commit -m $CommitMessage
} else {
    Write-Host "没有需要提交的变更。"
}

$existingRemote = git remote get-url origin 2>$null
if ($LASTEXITCODE -eq 0 -and $existingRemote) {
    git remote set-url origin $RepoUrl
} else {
    git remote add origin $RepoUrl
}

Write-Host ""
Write-Host "即将推送到：$RepoUrl（分支：$Branch）"
Write-Host "如果提示登录，请输入 GitHub 用户名，密码处粘贴 Fine-grained PAT。"
Write-Host ""
git push -u origin $Branch
