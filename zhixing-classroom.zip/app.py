"""知行教室 · 教室课程管理系统

启动方式：
    python app.py
    python app.py --port 8000 --host 127.0.0.1
"""

from __future__ import annotations

import argparse
import sys
from http.server import ThreadingHTTPServer

import database
from web import ApiHandler


class ClassroomServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def handle_error(self, request, client_address) -> None:
        exc = sys.exc_info()[1]
        if isinstance(exc, (ConnectionResetError, BrokenPipeError)):
            return
        super().handle_error(request, client_address)


def main() -> int:
    parser = argparse.ArgumentParser(description="知行教室 · 教室课程管理系统")
    parser.add_argument("--host", default="127.0.0.1", help="监听地址，默认 127.0.0.1")
    parser.add_argument("--port", type=int, default=8000, help="监听端口，默认 8000")
    args = parser.parse_args()

    database.init_db()

    try:
        httpd = ClassroomServer((args.host, args.port), ApiHandler)
    except OSError as exc:
        print(f"[ERROR] Cannot start server on {args.host}:{args.port}: {exc}", file=sys.stderr)
        print("[HINT] The port may be in use. Try: python app.py --port 8001", file=sys.stderr)
        return 1

    print("=" * 62)
    print("  Zhixing Classroom - Course & Classroom Management")
    print(f"  Local:   http://{args.host}:{args.port}")
    print(f"  Data:    {database.get_db_path()}")
    print("  Demo:    student / teacher / admin    password: 123456")
    print("  Stop:    Ctrl+C")
    print("=" * 62)

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
