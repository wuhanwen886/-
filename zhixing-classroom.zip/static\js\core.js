/* 核心工具：图标、状态、API、弹窗与通用格式化。 */

export const $ = (selector, root = document) => root.querySelector(selector);
export const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

export const state = {
  user: null,
  csrf: null,
  meta: null,
  page: "overview",
  overview: null,
  filters: null,
  borrowFilters: null,
  followNow: false,
  pollTimer: null,
  clockTimer: null,
  lastPage: null,
};

const PATHS = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.8"/><rect x="14" y="3" width="7" height="7" rx="1.8"/><rect x="3" y="14" width="7" height="7" rx="1.8"/><rect x="14" y="14" width="7" height="7" rx="1.8"/>',
  calendar: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 10h18"/><path d="M8 14h2M14 14h2M8 18h2M14 18h2"/>',
  door: '<path d="M4 21h16"/><path d="M6 21V4a1 1 0 0 1 1-1h9v18"/><path d="M9 12h.01"/><path d="M19 8v13"/>',
  clipboard: '<rect x="5" y="4" width="14" height="17" rx="2.5"/><path d="M9 4.5V3h6v1.5"/><path d="M9 9h6M9 13h6M9 17h4"/>',
  book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H20v3H6.5A2.5 2.5 0 0 1 4 20.5z"/>',
  building: '<rect x="4" y="3" width="16" height="18" rx="2.5"/><path d="M9 8h1M14 8h1M9 12h1M14 12h1M9 16h1M14 16h1"/><path d="M9 21v-2h6v2"/>',
  logout: '<path d="M10 17l5-5-5-5M15 12H3"/><path d="M14 4h4a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-4"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
  users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  check: '<path d="m5 12 4.5 4.5L19 7"/>',
  alert: '<path d="M10.3 3.9 2.4 17.4A2 2 0 0 0 4.1 20h15.8a2 2 0 0 0 1.7-2.6L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.3 6.7"/><path d="M20 4v7h-7"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.6-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.6-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.6V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.6 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.6 1z"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v5M14 11v5"/>',
  edit: '<path d="m14.5 4.5 5 5L8 21H3v-5z"/><path d="m12.5 6.5 5 5"/>',
  chevron: '<path d="m6 9 6 6 6-6"/>',
  lock: '<rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  spark: '<path d="m12 3 1.4 4.6L18 9l-4.6 1.4L12 15l-1.4-4.6L6 9l4.6-1.4z"/><path d="M19 15l.7 2.3L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.7z"/>',
  pin: '<path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0z"/><circle cx="12" cy="10" r="2.5"/>',
  monitor: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
  shield: '<path d="M12 22s8-3.5 8-10V5l-8-3-8 3v7c0 6.5 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
  arrowLeft: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
  dot: '<circle cx="12" cy="12" r="4" fill="currentColor" stroke="none"/>',
};

export function icon(name, className = "") {
  return `<svg class="icon ${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${PATHS[name] || ""}</svg>`;
}

export function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  })[char]);
}

export function initial(name) {
  return esc(String(name || "?").trim().slice(0, 1));
}

export const ROLE_LABELS = { student: "学生", teacher: "教师", admin: "管理员" };

export class ApiError extends Error {
  constructor(message, status = 0, details = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.details = details;
  }
}

export async function api(path, { method = "GET", body } = {}) {
  const options = {
    method,
    credentials: "same-origin",
    headers: { Accept: "application/json" },
  };
  if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  if (method !== "GET" && state.csrf) {
    options.headers["X-CSRF-Token"] = state.csrf;
  }

  const response = await fetch(`/api${path}`, options);
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  if (!response.ok) {
    if (response.status === 401 && state.user) {
      state.user = null;
      state.csrf = null;
      window.dispatchEvent(new CustomEvent("auth-expired"));
    }
    throw new ApiError(data.error || `请求失败（${response.status}）`, response.status, data.details || {});
  }
  return data;
}

export async function loadMeta() {
  state.meta = await api("/meta");
  return state.meta;
}

/* ------------------------------------------------------------------ */
/* 日期与时间                                                          */
/* ------------------------------------------------------------------ */

export function pad(value) {
  return String(value).padStart(2, "0");
}

export function dateString(date = new Date()) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function parseDate(value) {
  const [year, month, day] = String(value).split("-").map(Number);
  return new Date(year, month - 1, day);
}

export function addDays(value, amount) {
  const date = typeof value === "string" ? parseDate(value) : new Date(value);
  date.setDate(date.getDate() + amount);
  return date;
}

export const WEEKDAYS = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"];

export function weekdayLabel(value) {
  const date = typeof value === "string" ? parseDate(value) : value;
  return WEEKDAYS[(date.getDay() + 6) % 7];
}

export function formatDateCN(value, withWeekday = true) {
  const date = typeof value === "string" ? parseDate(value) : value;
  return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日${withWeekday ? ` · ${weekdayLabel(date)}` : ""}`;
}

export function formatShortDate(value) {
  const date = typeof value === "string" ? parseDate(value) : value;
  return `${date.getMonth() + 1}月${date.getDate()}日`;
}

export function relativeDate(value) {
  const today = dateString();
  const tomorrow = dateString(addDays(new Date(), 1));
  if (value === today) return "今天";
  if (value === tomorrow) return "明天";
  return formatShortDate(value);
}

export function timeToMinutes(value) {
  if (!value) return 0;
  const [hour, minute] = String(value).split(":").map(Number);
  return hour * 60 + (minute || 0);
}

export function minutesToTime(value) {
  return `${pad(Math.floor(value / 60))}:${pad(value % 60)}`;
}

export function nowMinutes() {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes();
}

export function nowTime() {
  return minutesToTime(nowMinutes());
}

export function formatDuration(start, end) {
  const minutes = timeToMinutes(end) - timeToMinutes(start);
  if (minutes <= 0) return "—";
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  if (!hours) return `${rest} 分钟`;
  if (!rest) return `${hours} 小时`;
  return `${hours} 小时 ${rest} 分`;
}

export function rangeOverlaps(start, end, otherStart, otherEnd) {
  return timeToMinutes(start) < timeToMinutes(otherEnd) && timeToMinutes(end) > timeToMinutes(otherStart);
}

export function roundUpTo(value, step = 5) {
  return Math.ceil(value / step) * step;
}

export function suggestedBorrowRange(room, fallbackTime) {
  let start = timeToMinutes(fallbackTime);
  if (room?.current) start = room.current.end_min;
  if (start < 480 || start >= 1320) start = 600;
  start = Math.min(1320, roundUpTo(start, 5));
  if (start >= 1260) start = 600;
  let end = Math.min(1320, start + 120);
  if (end - start < 30) {
    start = 600;
    end = 720;
  }
  return { start: minutesToTime(start), end: minutesToTime(end) };
}

export function defaultBorrowFilters() {
  const now = new Date();
  const current = now.getHours() * 60 + now.getMinutes();
  if (current < 720) {
    return { date: dateString(now), start: "12:10", end: "14:00", building: "", capacity: "", q: "" };
  }
  if (current >= 1230) {
    const tomorrow = addDays(now, 1);
    return {
      date: dateString(tomorrow),
      start: "12:10",
      end: "14:00",
      building: "",
      capacity: "",
      q: "",
    };
  }
  const start = Math.min(1260, roundUpTo(current + 30, 30));
  const end = Math.min(1320, start + 120);
  if (end - start < 60) {
    const tomorrow = addDays(now, 1);
    return {
      date: dateString(tomorrow),
      start: "12:10",
      end: "14:00",
      building: "",
      capacity: "",
      q: "",
    };
  }
  return {
    date: dateString(now),
    start: minutesToTime(start),
    end: minutesToTime(end),
    building: "",
    capacity: "",
    q: "",
  };
}

export function timestampLabel(value) {
  if (!value) return "--:--:--";
  const parts = String(value).split(" ");
  return parts[1] || value;
}

/* ------------------------------------------------------------------ */
/* 通用 UI                                                            */
/* ------------------------------------------------------------------ */

export function pageSkeleton(cards = 4) {
  return `
    <div class="skeleton-stats">
      ${Array.from({ length: 4 }, () => '<div class="skeleton sk-card"></div>').join("")}
    </div>
    <div class="skeleton-grid">
      ${Array.from({ length: cards }, () => '<div class="skeleton sk-room"></div>').join("")}
    </div>`;
}

export function emptyState(iconName, title, text, action = "") {
  return `
    <div class="empty-state">
      <div class="empty-icon">${icon(iconName)}</div>
      <h3>${esc(title)}</h3>
      <p>${esc(text)}</p>
      ${action ? `<div class="empty-action">${action}</div>` : ""}
    </div>`;
}

export function toast(message, type = "success") {
  const root = $("#toast-root");
  if (!root) return;
  const item = document.createElement("div");
  item.className = `toast toast-${type}`;
  const iconName = type === "error" ? "alert" : type === "info" ? "info" : "check";
  item.innerHTML = `<span class="toast-icon">${icon(iconName)}</span><span>${esc(message)}</span>`;
  root.appendChild(item);
  requestAnimationFrame(() => item.classList.add("is-visible"));
  setTimeout(() => {
    item.classList.remove("is-visible");
    setTimeout(() => item.remove(), 260);
  }, 3600);
}

export function formError(form, message) {
  const box = form?.querySelector(".form-error");
  if (!box) {
    toast(message, "error");
    return;
  }
  box.textContent = message;
  box.classList.add("is-visible");
  box.scrollIntoView({ block: "nearest", behavior: "smooth" });
}

export function clearFormError(form) {
  const box = form?.querySelector(".form-error");
  if (box) {
    box.textContent = "";
    box.classList.remove("is-visible");
  }
}

export function setButtonLoading(button, loading, label = "处理中...") {
  if (!button) return;
  if (loading) {
    button.dataset.original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = `<span class="btn-spinner"></span>${esc(label)}`;
  } else {
    button.disabled = false;
    if (button.dataset.original) {
      button.innerHTML = button.dataset.original;
      delete button.dataset.original;
    }
  }
}

/* ------------------------------------------------------------------ */
/* 弹窗                                                               */
/* ------------------------------------------------------------------ */

let activeModal = null;

export function openModal({
  title,
  subtitle = "",
  body = "",
  footer = "",
  size = "",
  onMount,
  onClose,
}) {
  closeActiveModal();

  const root = $("#modal-root");
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop";
  backdrop.innerHTML = `
    <div class="modal ${esc(size)}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="modal-head">
        <div>
          <h2>${esc(title)}</h2>
          ${subtitle ? `<p>${esc(subtitle)}</p>` : ""}
        </div>
        <button class="modal-close" type="button" aria-label="关闭">${icon("x")}</button>
      </div>
      <div class="modal-body">${body}</div>
      ${footer ? `<div class="modal-footer">${footer}</div>` : ""}
    </div>`;
  root.appendChild(backdrop);
  document.body.classList.add("modal-open");

  let closed = false;
  const close = (result) => {
    if (closed) return;
    closed = true;
    document.removeEventListener("keydown", onKeydown);
    backdrop.classList.remove("is-visible");
    document.body.classList.remove("modal-open");
    setTimeout(() => backdrop.remove(), 180);
    activeModal = null;
    if (onClose) onClose(result);
  };
  const onKeydown = (event) => {
    if (event.key === "Escape") close(false);
  };
  document.addEventListener("keydown", onKeydown);
  backdrop.querySelector(".modal-close")?.addEventListener("click", () => close(false));
  backdrop.addEventListener("mousedown", (event) => {
    if (event.target === backdrop) close(false);
  });

  activeModal = { backdrop, close };
  requestAnimationFrame(() => backdrop.classList.add("is-visible"));
  setTimeout(() => {
    backdrop.querySelector("[autofocus]")?.focus();
  }, 80);
  if (onMount) onMount(backdrop.querySelector(".modal"), close);
  return { element: backdrop.querySelector(".modal"), close };
}

export function closeActiveModal() {
  if (activeModal) {
    activeModal.close(false);
    activeModal = null;
  }
}

export function confirmDialog({
  title,
  message,
  confirmText = "确认",
  cancelText = "取消",
  danger = false,
}) {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    openModal({
      title,
      size: "modal-sm",
      body: `<div class="confirm-body"><div class="confirm-icon ${danger ? "is-danger" : ""}">${icon(danger ? "alert" : "info")}</div><p>${esc(message)}</p></div>`,
      footer: `
        <button type="button" class="btn btn-ghost" data-confirm-cancel>${esc(cancelText)}</button>
        <button type="button" class="btn ${danger ? "btn-danger" : "btn-primary"}" data-confirm-ok>${esc(confirmText)}</button>`,
      onMount(element, close) {
        element.querySelector("[data-confirm-cancel]").addEventListener("click", () => {
          finish(false);
          close(false);
        });
        element.querySelector("[data-confirm-ok]").addEventListener("click", () => {
          finish(true);
          close(true);
        });
      },
      onClose(result) {
        finish(result === true);
      },
    });
  });
}

/* ------------------------------------------------------------------ */
/* 业务状态文案                                                        */
/* ------------------------------------------------------------------ */

export function roomStateMeta(roomState) {
  return {
    free: { label: "空闲中", tone: "free" },
    busy: { label: "使用中", tone: "busy" },
    maintenance: { label: "维护中", tone: "maintenance" },
  }[roomState] || { label: "未知", tone: "muted" };
}

export function bookingStateMeta(bookingState) {
  return {
    active: { label: "已生效", tone: "free" },
    ended: { label: "已结束", tone: "muted" },
    cancelled: { label: "已取消", tone: "muted" },
  }[bookingState] || { label: "未知", tone: "muted" };
}

export function roomAvailabilityForRange(room, start, end) {
  if (!room || room.status !== "active") {
    return { available: false, conflicts: room?.intervals || [] };
  }
  const conflicts = (room.intervals || []).filter((item) =>
    rangeOverlaps(start, end, item.start, item.end)
  );
  return { available: conflicts.length === 0, conflicts };
}

export function roomLabel(room) {
  return room?.name || "";
}

export function getQuery(name) {
  return new URLSearchParams(location.search).get(name);
}
