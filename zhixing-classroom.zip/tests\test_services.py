"""业务层测试：认证、空闲计算、借用与课程冲突规则。

运行：
    python -m unittest discover -s tests -v
"""

from __future__ import annotations

import shutil
import sqlite3
import unittest
from datetime import date, timedelta
from pathlib import Path

import database
import services


class ServiceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        project_root = Path(__file__).resolve().parent.parent
        cls.temp_path = project_root / ".test_data"
        shutil.rmtree(cls.temp_path, ignore_errors=True)
        cls.temp_path.mkdir(parents=True, exist_ok=True)
        database.set_db_path(cls.temp_path / "test.db")
        database.init_db()

    @classmethod
    def tearDownClass(cls) -> None:
        shutil.rmtree(cls.temp_path, ignore_errors=True)

    def connect(self) -> sqlite3.Connection:
        return database.connect()

    def test_01_authentication(self) -> None:
        conn = self.connect()
        try:
            admin = services.authenticate(conn, "admin", "123456")
            self.assertEqual(admin["role"], "admin")
            self.assertEqual(admin["name"], "周明")
            with self.assertRaises(services.ApiError) as context:
                services.authenticate(conn, "admin", "wrong-password")
            self.assertEqual(context.exception.status, 401)
        finally:
            conn.close()

    def test_02_overview_and_room_order(self) -> None:
        conn = self.connect()
        try:
            data = services.get_overview(conn, date.today().isoformat(), "10:10")
            self.assertEqual(len(data["classrooms"]), 12)
            self.assertEqual(data["classrooms"][0]["name"], "综合楼 A101")
            self.assertGreaterEqual(sum(1 for room in data["classrooms"] if room["state"] == "busy"), 1)
            self.assertTrue(1 <= data["week"] <= 18)
            self.assertIn("intervals", data["classrooms"][0])
        finally:
            conn.close()

    def test_03_schedule_and_semester(self) -> None:
        conn = self.connect()
        try:
            student = services.authenticate(conn, "student", "123456")
            schedule = services.get_schedule(conn, student)
            self.assertGreater(schedule["stats"]["course_count"], 0)
            self.assertEqual(len(schedule["days"]), 7)
            self.assertTrue(all(course["class_name"] == student["class_name"] for course in schedule["courses"]))
            semester = services.semester_info(conn)
            self.assertGreaterEqual(semester["week"], 1)
        finally:
            conn.close()

    def test_04_booking_conflicts(self) -> None:
        conn = self.connect()
        try:
            teacher = services.authenticate(conn, "teacher", "123456")
            other = services.authenticate(conn, "lina", "123456")
            tomorrow = (date.today() + timedelta(days=1)).isoformat()
            payload = {
                "classroom_id": 4,
                "date": tomorrow,
                "start_time": "12:00",
                "end_time": "13:00",
                "purpose": "单元测试借用",
            }
            booking = services.create_booking(conn, teacher, payload)
            self.assertEqual(booking["classroom_name"], "综合楼 A202")
            with self.assertRaises(services.ApiError) as context:
                services.create_booking(conn, teacher, payload)
            self.assertIn("时间冲突", context.exception.message)
            with self.assertRaises(services.ApiError) as context:
                services.create_booking(conn, other, payload)
            self.assertIn("时间冲突", context.exception.message)
            cancelled = services.cancel_booking(conn, teacher, booking["id"])
            self.assertEqual(cancelled["state"], "cancelled")
        finally:
            conn.close()

    def test_05_course_conflicts_and_crud(self) -> None:
        conn = self.connect()
        try:
            admin = services.authenticate(conn, "admin", "123456")
            base = {
                "code": "TST101",
                "name": "测试课程",
                "teacher_id": 3,
                "classroom_id": 1,
                "class_name": "测试班级",
                "weekday": 2,
                "start_time": "10:05",
                "end_time": "11:40",
                "weeks_start": 1,
                "weeks_end": 18,
            }
            with self.assertRaises(services.ApiError) as context:
                services.create_course(conn, admin, base)
            self.assertIn("教室冲突", context.exception.message)

            class_conflict = {**base, "classroom_id": 12, "class_name": "计算机2301"}
            with self.assertRaises(services.ApiError) as context:
                services.create_course(conn, admin, class_conflict)
            self.assertIn("班级冲突", context.exception.message)

            created = services.create_course(
                conn,
                admin,
                {
                    **base,
                    "code": "TST102",
                    "classroom_id": 12,
                    "class_name": "测试班级",
                    "weekday": 6,
                    "start_time": "18:00",
                    "end_time": "19:30",
                },
            )
            self.assertEqual(created["weekday_label"], "周六")
            updated = services.update_course(conn, admin, created["id"], {**base, "name": "测试课程（修改）", "classroom_id": 12, "class_name": "测试班级", "weekday": 6, "start_time": "18:00", "end_time": "19:30"})
            self.assertIn("修改", updated["name"])
            services.delete_course(conn, admin, created["id"])
            with self.assertRaises(services.ApiError) as context:
                services.update_course(conn, admin, created["id"], base)
            self.assertEqual(context.exception.status, 404)
        finally:
            conn.close()

    def test_06_classroom_and_settings(self) -> None:
        conn = self.connect()
        try:
            admin = services.authenticate(conn, "admin", "123456")
            meta = services.get_meta(conn)
            self.assertEqual(meta["buildings"][0], "综合楼")
            room = services.create_classroom(
                conn,
                admin,
                {
                    "name": "测试楼 T101",
                    "building": "测试楼",
                    "room_no": "T101",
                    "capacity": 30,
                    "room_type": "研讨室",
                    "equipment": "投屏,白板",
                    "status": "active",
                },
            )
            self.assertEqual(room["building"], "测试楼")
            room = services.update_classroom(
                conn,
                admin,
                room["id"],
                {
                    "name": room["name"],
                    "building": room["building"],
                    "room_no": room["room_no"],
                    "capacity": room["capacity"],
                    "room_type": room["room_type"],
                    "equipment": "投屏,白板",
                    "status": "maintenance",
                },
            )
            self.assertEqual(room["status"], "maintenance")
            semester = services.update_semester(conn, admin, {"start": "2026-09-01", "name": "测试学期"})
            self.assertEqual(semester["start"], "2026-08-31")
        finally:
            conn.close()


if __name__ == "__main__":
    unittest.main()
