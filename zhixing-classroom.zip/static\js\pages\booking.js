/* 教室借用：借用弹窗、查找空闲教室、我的借用与管理员借用记录。 */

import {
  $,
  $$,
  state,
  icon,
  esc,
  api,
  openModal,
  toast,
  confirmDialog,
  emptyState,
  formatDateCN,
  formatShortDate,
  relativeDate,
  weekdayLabel,
  timeToMinutes,
  minutesToTime,
  nowMinutes,
  dateString,
  defaultBorrowFilters,
  rangeOverlaps,
  suggestedBorrowRange,
  roomAvailabilityForRange,
  bookingStateMeta,
  setButtonLoading,
  formError,
  clearFormError,
} from "../core.js";

/* ------------------------------------------------------------------ */
/* 借用弹窗                                                            */
/* ------------------------------------------------------------------ */

export function openBorrowModal(room, options = {}) {
  const today = dateString();
  let date = options.date || today;
  let start = options.start;
  let end = options.end;
  if (date < today) {
    const fallback = defaultBorrowFilters();
    date = fallback.date;
    start = fallback.start;
    end = fallback.end;
  }
  if (!start || !end) {
    const range = suggestedBorrowRange(room, options.at || "10:00");
    start = range.start;
    end = range.end;
  }
  if (timeToMinutes(end) <= timeToMinutes(start)) {
    const range = suggestedBorrowRange(room, "10:00");
    start = range.start;
    end = range.end;
  }

  const body = `
    <form id="borrow-form" class="stack-form" novalidate>
      <div class="form-error" role="alert"></div>
      <div class="borrow-room-summary">
        <div class="room-icon">${icon("door")}</div>
        <div>
          <strong>${esc(room.name)}</strong>
          <span>${esc(room.building)} · ${esc(room.room_type)} · ${room.capacity} 人</span>
        </div>
        <span class="status-pill status-free"><i></i>可借用</span>
      </div>

      <div class="form-grid two">
        <label class="field">
          <span>借用日期</span>
          <input type="date" name="date" id="borrow-date" min="${today}" value="${date}" required>
        </label>
        <label class="field">
          <span>借用时段</span>
          <div class="time-range">
            <input type="time" name="start_time" id="borrow-start" step="300" value="${start}" required>
            <span>至</span>
            <input type="time" name="end_time" id="borrow-end" step="300" value="${end}" required>
          </div>
        </label>
      </div>

      <label class="field">
        <span>借用用途</span>
        <textarea name="purpose" id="borrow-purpose" rows="3" maxlength="100" placeholder="例如：课程组教研会议、毕业设计答疑、学科竞赛辅导" autofocus required></textarea>
        <small class="field-hint" id="duration-hint">借用时长 ${durationLabel(start, end)}</small>
      </label>

      <div class="form-note">${icon("info")}借用提交后立即生效。如与课程或其他借用冲突，系统将自动拦截。</div>
    </form>`;

  const modal = openModal({
    title: "借用教室",
    subtitle: `${room.name} · ${room.building}`,
    size: "modal-md",
    body,
    footer: `
      <button type="button" class="btn btn-ghost" data-cancel>取消</button>
      <button type="submit" class="btn btn-primary" form="borrow-form" data-submit>${icon("check")}确认借用</button>`,
  });

  const form = modal.element.querySelector("#borrow-form");
  const startInput = modal.element.querySelector("#borrow-start");
  const endInput = modal.element.querySelector("#borrow-end");
  const hint = modal.element.querySelector("#duration-hint");
  const submit = modal.element.querySelector("[data-submit]");

  const updateHint = () => {
    if (!hint) return;
    const value = durationLabel(startInput.value, endInput.value);
    hint.textContent = value === "—" ? "请选择有效的借用时段" : `借用时长 ${value}`;
  };
  startInput?.addEventListener("change", updateHint);
  endInput?.addEventListener("change", updateHint);
  modal.element.querySelector("[data-cancel]")?.addEventListener("click", () => modal.close());
  form?.addEventListener("input", () => clearFormError(form));

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearFormError(form);
    const data = Object.fromEntries(new FormData(form).entries());
    const startMin = timeToMinutes(data.start_time);
    const endMin = timeToMinutes(data.end_time);
    if (!data.date || !data.start_time || !data.end_time) {
      formError(form, "请选择借用日期和时段");
      return;
    }
    if (data.date < today) {
      formError(form, "不能借用过去的日期");
      return;
    }
    if (endMin <= startMin) {
      formError(form, "结束时间必须晚于开始时间");
      return;
    }
    if (startMin < 480 || endMin > 1320) {
      formError(form, "借用时段需在 08:00-22:00 之间");
      return;
    }
    if (!data.purpose.trim()) {
      formError(form, "请填写借用用途");
      return;
    }

    setButtonLoading(submit, true, "提交中...");
    try {
      const result = await api("/bookings", {
        method: "POST",
        body: {
          classroom_id: room.id,
          date: data.date,
          start_time: data.start_time,
          end_time: data.end_time,
          purpose: data.purpose.trim(),
        },
      });
      toast(`已成功借用 ${result.booking.classroom_name}`);
      modal.close(true);
      if (options.onSuccess) options.onSuccess(result.booking);
    } catch (error) {
      formError(form, error.message);
      setButtonLoading(submit, false);
    }
  });
}

function durationLabel(start, end) {
  const minutes = timeToMinutes(end) - timeToMinutes(start);
  if (!Number.isFinite(minutes) || minutes <= 0) return "—";
  const hours = Math.floor(minutes / 60);
  const rest = minutes % 60;
  if (!hours) return `${rest} 分钟`;
  if (!rest) return `${hours} 小时`;
  return `${hours} 小时 ${rest} 分`;
}

/* ------------------------------------------------------------------ */
/* 教师：查找空闲教室                                                  */
/* ------------------------------------------------------------------ */

function initBorrowFilters() {
  const filters = state.borrowFilters || defaultBorrowFilters();
  const today = dateString();
  if (filters.date < today || (filters.date === today && timeToMinutes(filters.end) <= nowMinutes())) {
    Object.assign(filters, defaultBorrowFilters());
  }
  state.borrowFilters = filters;
}

export async function renderBorrowPage(content) {
  initBorrowFilters();
  const filters = state.borrowFilters;

  content.innerHTML = `
    <div class="page-heading">
      <div>
        <div class="eyebrow">ROOM BOOKING</div>
        <h1>借用空闲教室</h1>
        <p>选择日期与时段，系统会为你筛出整段时间都可用的教室。</p>
      </div>
      <div class="heading-actions">
        <button type="button" class="btn btn-ghost" data-action="my-bookings">${icon("clipboard")}我的借用</button>
      </div>
    </div>

    <div class="notice notice-info">
      <span class="notice-icon">${icon("info")}</span>
      <span>教师借用即时生效。提交前请确认时段与用途，管理员可在借用管理中查看记录。</span>
    </div>

    <section class="filter-card borrow-filter-card">
      <div class="borrow-filter-grid">
        <label class="compact-field">
          <span>借用日期</span>
          <input type="date" id="borrow-filter-date" min="${dateString()}" value="${filters.date}">
        </label>
        <label class="compact-field">
          <span>开始时间</span>
          <input type="time" id="borrow-filter-start" step="300" value="${filters.start}">
        </label>
        <label class="compact-field">
          <span>结束时间</span>
          <input type="time" id="borrow-filter-end" step="300" value="${filters.end}">
        </label>
        <label class="compact-field">
          <span>教学楼</span>
          <select id="borrow-filter-building">
            <option value="">全部楼栋</option>
            ${(state.meta.buildings || []).map((building) => `<option value="${esc(building)}" ${filters.building === building ? "selected" : ""}>${esc(building)}</option>`).join("")}
          </select>
        </label>
        <label class="compact-field">
          <span>容量</span>
          <select id="borrow-filter-capacity">
            <option value="">不限容量</option>
            <option value="40" ${filters.capacity === "40" ? "selected" : ""}>40 人以上</option>
            <option value="60" ${filters.capacity === "60" ? "selected" : ""}>60 人以上</option>
            <option value="100" ${filters.capacity === "100" ? "selected" : ""}>100 人以上</option>
          </select>
        </label>
        <button type="button" class="btn btn-primary btn-search-rooms" id="borrow-search">${icon("search")}查找教室</button>
      </div>
      <div class="filter-bottom">
        <div class="segmented" id="borrow-building-tabs">
          <button type="button" class="segment ${!filters.building ? "is-active" : ""}" data-borrow-building="">全部</button>
          ${(state.meta.buildings || []).map((building) => `<button type="button" class="segment ${filters.building === building ? "is-active" : ""}" data-borrow-building="${esc(building)}">${esc(building)}</button>`).join("")}
        </div>
        <div class="filter-count" id="borrow-count">正在查找可用教室…</div>
      </div>
    </section>

    <div id="borrow-notice"></div>
    <div class="section-head">
      <div>
        <h2>可用教室 <span class="section-badge" id="borrow-slot-badge"></span></h2>
        <p>绿色卡片表示所选时段内整段空闲</p>
      </div>
      <div class="legend">
        <span><i class="legend-dot free"></i>可借用</span>
        <span><i class="legend-dot busy"></i>时间冲突</span>
      </div>
    </div>
    <section class="borrow-grid" id="borrow-results"></section>`;

  bindBorrowControls(content);
  await loadBorrowRooms(true);
}

function bindBorrowControls(content) {
  const date = $("#borrow-filter-date", content);
  const start = $("#borrow-filter-start", content);
  const end = $("#borrow-filter-end", content);
  const building = $("#borrow-filter-building", content);
  const capacity = $("#borrow-filter-capacity", content);

  const syncAndLoad = () => {
    state.borrowFilters.date = date.value;
    state.borrowFilters.start = start.value;
    state.borrowFilters.end = end.value;
    loadBorrowRooms(false);
  };
  date.addEventListener("change", syncAndLoad);
  start.addEventListener("change", syncAndLoad);
  end.addEventListener("change", syncAndLoad);
  $("#borrow-search", content).addEventListener("click", syncAndLoad);
  building.addEventListener("change", () => {
    state.borrowFilters.building = building.value;
    $$("#borrow-building-tabs .segment", content).forEach((item) =>
      item.classList.toggle("is-active", item.dataset.borrowBuilding === building.value)
    );
    renderBorrowResults();
  });
  capacity.addEventListener("change", () => {
    state.borrowFilters.capacity = capacity.value;
    renderBorrowResults();
  });
  $$("#borrow-building-tabs .segment", content).forEach((button) => {
    button.addEventListener("click", () => {
      building.value = button.dataset.borrowBuilding;
      state.borrowFilters.building = building.value;
      $$("#borrow-building-tabs .segment", content).forEach((item) => item.classList.toggle("is-active", item === button));
      renderBorrowResults();
    });
  });
  $("[data-action='my-bookings']", content)?.addEventListener("click", () => {
    location.hash = "#/bookings";
  });
}

async function loadBorrowRooms(showLoading) {
  const filters = state.borrowFilters;
  const notice = $("#borrow-notice");
  const results = $("#borrow-results");
  if (!results) return;

  const startMin = timeToMinutes(filters.start);
  const endMin = timeToMinutes(filters.end);
  if (!filters.date || !filters.start || !filters.end) {
    showBorrowNotice("请选择完整的借用日期与时段。");
    return;
  }
  if (endMin <= startMin) {
    showBorrowNotice("结束时间必须晚于开始时间。");
    results.innerHTML = emptyState("clock", "时段不正确", "请调整开始时间和结束时间。");
    return;
  }
  if (startMin < 480 || endMin > 1320) {
    showBorrowNotice("借用时间需在 08:00-22:00 之间。");
    results.innerHTML = emptyState("clock", "不在开放时段", "教室开放时间为每天 08:00-22:00。");
    return;
  }
  if (filters.date < dateString()) {
    showBorrowNotice("不能借用过去的日期。");
    results.innerHTML = emptyState("calendar", "日期已过", "请选择今天或之后的日期。");
    return;
  }
  showBorrowNotice("");

  if (showLoading) {
    results.innerHTML = `<div class="skeleton-grid borrow-skeleton">${Array.from({ length: 6 }, () => '<div class="skeleton sk-borrow"></div>').join("")}</div>`;
  }

  try {
    const data = await api(`/overview?date=${encodeURIComponent(filters.date)}&at=${encodeURIComponent(filters.start)}`);
    if (state.page !== "borrow") return;
    state.borrowData = data;
    renderBorrowResults();
    const badge = $("#borrow-slot-badge");
    if (badge) {
      badge.textContent = `${formatShortDate(filters.date)} ${weekdayLabel(filters.date)} ${filters.start}-${filters.end}`;
    }
  } catch (error) {
    showBorrowNotice(error.message, "error");
    results.innerHTML = emptyState("alert", "查找失败", error.message);
  }
}

function showBorrowNotice(message, tone = "info", actionHtml = "") {
  const holder = $("#borrow-notice");
  if (!holder) return;
  const iconName = tone === "error" ? "alert" : tone === "warning" ? "clock" : "info";
  holder.innerHTML = message
    ? `<div class="notice notice-${tone}"><span class="notice-icon">${icon(iconName)}</span><span>${esc(message)}</span>${actionHtml}</div>`
    : "";
}

function nextTeacherFreeRange(intervals, selectedStart, duration = 90) {
  let start = Math.max(480, timeToMinutes(selectedStart));
  if (state.borrowFilters.date === dateString()) {
    start = Math.max(start, Math.ceil((nowMinutes() + 10) / 5) * 5);
  }
  const busy = [...intervals].sort((a, b) => a.start_min - b.start_min);
  for (let guard = 0; guard < 20; guard += 1) {
    const covering = busy.find((item) => start >= item.start_min && start < item.end_min);
    if (covering) {
      start = covering.end_min + 10;
      continue;
    }
    const upcoming = busy.find((item) => item.start_min > start);
    if (upcoming && upcoming.start_min - start < duration) {
      start = upcoming.end_min + 10;
      continue;
    }
    if (start + duration <= 1320) {
      return { start: minutesToTime(start), end: minutesToTime(start + duration) };
    }
    return null;
  }
  return null;
}

function renderBorrowResults() {
  const data = state.borrowData;
  const holder = $("#borrow-results");
  if (!data || !holder) return;
  const filters = state.borrowFilters;
  const slotPassed =
    filters.date < dateString() ||
    (filters.date === dateString() && timeToMinutes(filters.end) <= nowMinutes());
  const teacherConflicts = (data.teacher_intervals || []).filter((item) =>
    rangeOverlaps(filters.start, filters.end, item.start, item.end)
  );
  if (teacherConflicts.length) {
    const detail = teacherConflicts
      .map((item) => `${item.start}-${item.end} ${item.title}（${item.subtitle}）`)
      .slice(0, 2)
      .join("；");
    const suggestion = slotPassed ? null : nextTeacherFreeRange(data.teacher_intervals || [], filters.start);
    const action = suggestion
      ? `<button type="button" class="notice-btn" data-use-suggestion="${suggestion.start}-${suggestion.end}">采用建议 ${suggestion.start}-${suggestion.end}</button>`
      : "";
    showBorrowNotice(`你在所选时段已有安排：${detail}。请调整开始或结束时间。`, "warning", action);
    const suggestionButton = $("#borrow-notice [data-use-suggestion]");
    if (suggestionButton) {
      suggestionButton.addEventListener("click", () => {
        const [nextStart, nextEnd] = suggestionButton.dataset.useSuggestion.split("-");
        state.borrowFilters.start = nextStart;
        state.borrowFilters.end = nextEnd;
        const startInput = $("#borrow-filter-start");
        const endInput = $("#borrow-filter-end");
        if (startInput) startInput.value = nextStart;
        if (endInput) endInput.value = nextEnd;
        loadBorrowRooms(true);
      });
    }
  }

  let rooms = data.classrooms.filter((room) => {
    if (filters.building && room.building !== filters.building) return false;
    if (filters.capacity && room.capacity < Number(filters.capacity)) return false;
    return true;
  });

  rooms = rooms.map((room) => {
    const range = roomAvailabilityForRange(room, filters.start, filters.end);
    return { room, ...range, passed: slotPassed, teacherConflict: teacherConflicts.length > 0 };
  });
  rooms.sort((a, b) => {
    if (a.available !== b.available) return a.available ? -1 : 1;
    return a.room.name.localeCompare(b.room.name, "zh-CN");
  });

  const availableCount = rooms.filter(
    (item) => item.available && !item.passed && !item.teacherConflict
  ).length;
  const count = $("#borrow-count");
  if (count) count.textContent = `${availableCount} 间可借用 · 共 ${rooms.length} 间教室`;

  if (!rooms.length) {
    holder.innerHTML = emptyState("search", "没有符合条件的教室", "请调整楼栋或容量筛选条件。");
    return;
  }

  holder.innerHTML = rooms.map(({ room, available, conflicts, passed, teacherConflict }) => {
    const disabled = !available || passed || teacherConflict;
    let statusHtml = "";
    if (passed) {
      statusHtml = `<div class="borrow-state is-muted">${icon("clock")}<div><strong>时段已过</strong><span>请选择今天稍后的时间或未来日期</span></div></div>`;
    } else if (teacherConflict) {
      statusHtml = `<div class="borrow-state is-conflict">${icon("clock")}<div><strong>教师时间冲突</strong><span>你在该时段已有课程或借用</span></div></div>`;
    } else if (available) {
      statusHtml = `<div class="borrow-state is-free">${icon("check")}<div><strong>整段时段可借用</strong><span>${filters.start} - ${filters.end} · ${durationLabel(filters.start, filters.end)}</span></div></div>`;
    } else {
      const conflictText = conflicts
        .map((item) => `${item.start}-${item.end} ${item.title}`)
        .slice(0, 2)
        .join("；");
      statusHtml = `<div class="borrow-state is-conflict">${icon("alert")}<div><strong>时间冲突</strong><span>${esc(conflictText || "该时段已有安排")}</span></div></div>`;
    }

    return `
      <article class="borrow-card ${available && !passed && !teacherConflict ? "is-available" : "is-unavailable"}">
        <div class="borrow-card-head">
          <div class="room-title-wrap">
            <div class="room-icon">${icon("door")}</div>
            <div>
              <h3>${esc(room.name)}</h3>
              <p>${esc(room.building)} · ${esc(room.room_type)}</p>
            </div>
          </div>
          <span class="soft-badge">${room.capacity} 人</span>
        </div>
        <div class="borrow-facts">
          ${room.equipment.slice(0, 3).map((item) => `<span>${icon("monitor")} ${esc(item)}</span>`).join("") || "<span>暂无设备信息</span>"}
        </div>
        ${statusHtml}
        <div class="borrow-card-foot">
          <span class="borrow-time">${icon("clock")}${filters.start} - ${filters.end}</span>
          <button type="button" class="btn ${available && !passed && !teacherConflict ? "btn-primary" : "btn-ghost"} btn-sm" data-borrow-room="${room.id}" ${disabled ? "disabled" : ""}>
            ${passed ? "时段已过" : teacherConflict ? "时间冲突" : available ? `${icon("door")}立即借用` : "不可借用"}
          </button>
        </div>
      </article>`;
  }).join("");

  holder.onclick = (event) => {
    const button = event.target.closest("[data-borrow-room]");
    if (!button || button.disabled) return;
    const room = data.classrooms.find((item) => item.id === Number(button.dataset.borrowRoom));
    if (!room) return;
    openBorrowModal(room, {
      date: filters.date,
      start: filters.start,
      end: filters.end,
      onSuccess: () => loadBorrowRooms(false),
    });
  };
}

/* ------------------------------------------------------------------ */
/* 教师：我的借用                                                      */
/* ------------------------------------------------------------------ */

export async function renderMyBookingsPage(content) {
  content.innerHTML = `
    <div class="page-heading">
      <div>
        <div class="eyebrow">MY BOOKINGS</div>
        <h1>我的借用</h1>
        <p>查看已提交的教室借用，并在使用前取消不再需要的安排。</p>
      </div>
      <div class="heading-actions">
        <button type="button" class="btn btn-primary" data-action="go-borrow">${icon("plus")}借用教室</button>
      </div>
    </div>
    <div id="booking-stats" class="stats-grid stats-grid-mini"></div>
    <div id="booking-list" class="booking-list-wrap">
      <div class="page-loading-inline"><span class="spinner"></span>正在载入借用记录...</div>
    </div>`;

  $("[data-action='go-borrow']", content)?.addEventListener("click", () => {
    location.hash = "#/borrow";
  });
  await loadMyBookings();
}

async function loadMyBookings() {
  try {
    const data = await api("/bookings");
    if (state.page !== "bookings") return;
    const upcoming = data.bookings
      .filter((item) => item.state === "active")
      .sort((a, b) => `${a.date} ${a.start_time}`.localeCompare(`${b.date} ${b.start_time}`));
    const history = data.bookings
      .filter((item) => item.state !== "active")
      .sort((a, b) => `${b.date} ${b.start_time}`.localeCompare(`${a.date} ${a.start_time}`));
    renderBookingStats(upcoming, history);
    renderBookingList(upcoming, history);
  } catch (error) {
    $("#booking-list").innerHTML = emptyState("alert", "读取失败", error.message);
  }
}

function renderBookingStats(upcoming, history) {
  const holder = $("#booking-stats");
  if (!holder) return;
  const cancelled = history.filter((item) => item.state === "cancelled").length;
  holder.innerHTML = `
    <article class="stat-card stat-free stat-card-horizontal">
      <div class="stat-icon">${icon("calendar")}</div>
      <div class="stat-body"><span class="stat-label">即将使用</span><div class="stat-value">${upcoming.length}<small>条</small></div></div>
    </article>
    <article class="stat-card stat-muted stat-card-horizontal">
      <div class="stat-icon">${icon("check")}</div>
      <div class="stat-body"><span class="stat-label">历史记录</span><div class="stat-value">${history.length}<small>条</small></div></div>
    </article>
    <article class="stat-card stat-book stat-card-horizontal">
      <div class="stat-icon">${icon("x")}</div>
      <div class="stat-body"><span class="stat-label">已取消</span><div class="stat-value">${cancelled}<small>条</small></div></div>
    </article>`;
}

function renderBookingList(upcoming, history) {
  const holder = $("#booking-list");
  if (!holder) return;
  if (!upcoming.length && !history.length) {
    holder.innerHTML = emptyState(
      "door",
      "还没有借用记录",
      "去借用一间空闲教室，为课程讨论或教研活动预留空间。",
      `<button type="button" class="btn btn-primary" data-action="empty-borrow">${icon("plus")}借用教室</button>`
    );
    holder.querySelector("[data-action='empty-borrow']")?.addEventListener("click", () => {
      location.hash = "#/borrow";
    });
    return;
  }

  holder.innerHTML = `
    ${upcoming.length ? `
      <div class="section-head compact-head">
        <div><h2>即将使用 <span class="section-badge">${upcoming.length}</span></h2><p>借用已生效，可在开始前取消</p></div>
      </div>
      <div class="booking-list">${upcoming.map((item) => bookingItem(item, true)).join("")}</div>` : ""}
    ${history.length ? `
      <div class="section-head compact-head">
        <div><h2>历史记录 <span class="section-badge">${history.length}</span></h2><p>已结束或已取消的借用</p></div>
      </div>
      <div class="booking-list">${history.map((item) => bookingItem(item, false)).join("")}</div>` : ""}`;

  holder.onclick = (event) => {
    const button = event.target.closest("[data-cancel-booking]");
    if (!button) return;
    cancelBooking(Number(button.dataset.cancelBooking), loadMyBookings);
  };
}

function bookingItem(booking, active) {
  const date = new Date(`${booking.date}T00:00:00`);
  const meta = bookingStateMeta(booking.state);
  return `
    <article class="booking-item ${active ? "" : "is-history"}">
      <div class="booking-date">
        <strong>${String(date.getDate()).padStart(2, "0")}</strong>
        <span>${date.getMonth() + 1} 月</span>
        <em>${weekdayLabel(booking.date)}</em>
      </div>
      <div class="booking-main">
        <div class="booking-title">
          <h3>${esc(booking.classroom_name)}</h3>
          <span class="status-pill status-${meta.tone}"><i></i>${meta.label}</span>
          ${active ? `<span class="relative-chip">${relativeDate(booking.date)}</span>` : ""}
        </div>
        <div class="booking-meta">
          <span>${icon("calendar")}${formatDateCN(booking.date)}</span>
          <span>${icon("clock")}${booking.start_time} - ${booking.end_time}</span>
          <span>${icon("pin")}${esc(booking.building)}</span>
        </div>
        <p class="booking-purpose">${esc(booking.purpose)}</p>
      </div>
      <div class="booking-action">
        ${active ? `<button type="button" class="btn btn-ghost btn-sm btn-danger-text" data-cancel-booking="${booking.id}">取消借用</button>` : ""}
      </div>
    </article>`;
}

async function cancelBooking(id, onSuccess) {
  const confirmed = await confirmDialog({
    title: "取消借用",
    message: "取消后该时段将重新开放给其他教师借用，确定继续吗？",
    confirmText: "确认取消",
    danger: true,
  });
  if (!confirmed) return;
  try {
    await api(`/bookings/${id}`, { method: "DELETE" });
    toast("借用已取消");
    if (onSuccess) await onSuccess();
  } catch (error) {
    toast(error.message, "error");
  }
}

/* ------------------------------------------------------------------ */
/* 管理员：借用管理                                                    */
/* ------------------------------------------------------------------ */

export async function renderAdminBookingsPage(content) {
  content.innerHTML = `
    <div class="page-heading">
      <div>
        <div class="eyebrow">BOOKING ADMIN</div>
        <h1>借用管理</h1>
        <p>查看全校教师提交的教室借用，必要时可取消异常记录。</p>
      </div>
      <div class="heading-actions">
        <button type="button" class="btn btn-ghost" data-action="refresh-bookings">${icon("refresh")}刷新</button>
      </div>
    </div>
    <div id="admin-booking-stats" class="stats-grid stats-grid-mini"></div>
    <section class="filter-card">
      <div class="filter-grid admin-booking-filter">
        <label class="compact-field search-field">
          <span>搜索记录</span>
          <div class="search-input">${icon("search")}<input type="search" id="admin-booking-q" placeholder="教师 / 教室 / 用途"></div>
        </label>
        <label class="compact-field">
          <span>状态</span>
          <select id="admin-booking-status">
            <option value="all">全部状态</option>
            <option value="active">已生效</option>
            <option value="ended">已结束</option>
            <option value="cancelled">已取消</option>
          </select>
        </label>
      </div>
      <div class="filter-bottom">
        <div class="filter-count" id="admin-booking-count">正在载入…</div>
      </div>
    </section>
    <section class="table-card" id="admin-booking-table">
      <div class="page-loading-inline"><span class="spinner"></span>正在载入借用记录...</div>
    </section>`;

  $("[data-action='refresh-bookings']", content)?.addEventListener("click", () => loadAdminBookings(true));
  $("#admin-booking-q", content)?.addEventListener("input", renderAdminBookingTable);
  $("#admin-booking-status", content)?.addEventListener("change", renderAdminBookingTable);
  await loadAdminBookings(true);
}

async function loadAdminBookings(showLoading) {
  const table = $("#admin-booking-table");
  if (!table) return;
  if (showLoading) {
    table.innerHTML = `<div class="page-loading-inline"><span class="spinner"></span>正在载入借用记录...</div>`;
  }
  try {
    const data = await api("/bookings");
    if (state.page !== "admin-bookings") return;
    state.adminBookings = data.bookings;
    renderAdminBookingStats(data.bookings);
    renderAdminBookingTable();
  } catch (error) {
    table.innerHTML = emptyState("alert", "读取失败", error.message);
  }
}

function renderAdminBookingStats(bookings) {
  const holder = $("#admin-booking-stats");
  if (!holder) return;
  const active = bookings.filter((item) => item.state === "active").length;
  const ended = bookings.filter((item) => item.state === "ended").length;
  const cancelled = bookings.filter((item) => item.state === "cancelled").length;
  holder.innerHTML = `
    <article class="stat-card stat-free stat-card-horizontal"><div class="stat-icon">${icon("check")}</div><div class="stat-body"><span class="stat-label">已生效</span><div class="stat-value">${active}<small>条</small></div></div></article>
    <article class="stat-card stat-busy stat-card-horizontal"><div class="stat-icon">${icon("clock")}</div><div class="stat-body"><span class="stat-label">已结束</span><div class="stat-value">${ended}<small>条</small></div></div></article>
    <article class="stat-card stat-muted stat-card-horizontal"><div class="stat-icon">${icon("x")}</div><div class="stat-body"><span class="stat-label">已取消</span><div class="stat-value">${cancelled}<small>条</small></div></div></article>`;
}

function renderAdminBookingTable() {
  const holder = $("#admin-booking-table");
  if (!holder) return;
  const all = state.adminBookings || [];
  const q = ($("#admin-booking-q")?.value || "").trim().toLowerCase();
  const status = $("#admin-booking-status")?.value || "all";
  const rows = all.filter((item) => {
    if (status !== "all" && item.state !== status) return false;
    if (q) {
      const text = `${item.teacher_name} ${item.classroom_name} ${item.purpose} ${item.date}`.toLowerCase();
      if (!text.includes(q)) return false;
    }
    return true;
  });

  const count = $("#admin-booking-count");
  if (count) count.textContent = `共 ${all.length} 条记录 · 当前显示 ${rows.length} 条`;

  if (!rows.length) {
    holder.innerHTML = emptyState("clipboard", "暂无借用记录", "当前筛选条件下没有匹配的借用记录。");
    return;
  }

  holder.innerHTML = `
    <div class="table-scroll">
      <table class="data-table booking-admin-table">
        <thead>
          <tr><th>教师</th><th>教室</th><th>日期</th><th>时段</th><th>用途</th><th>状态</th><th></th></tr>
        </thead>
        <tbody>
          ${rows.map((item) => {
            const meta = bookingStateMeta(item.state);
            return `
              <tr>
                <td><div class="person-cell"><span class="avatar avatar-sm">${esc(item.teacher_name.slice(0, 1))}</span><strong>${esc(item.teacher_name)}</strong></div></td>
                <td><div class="room-cell"><strong>${esc(item.classroom_name)}</strong><span>${esc(item.building)}</span></div></td>
                <td><span class="nowrap">${formatDateCN(item.date)}</span></td>
                <td><span class="nowrap">${item.start_time} - ${item.end_time}</span></td>
                <td class="purpose-cell">${esc(item.purpose)}</td>
                <td><span class="status-pill status-${meta.tone}"><i></i>${meta.label}</span></td>
                <td class="actions-cell">${item.state === "active" ? `<button type="button" class="table-action danger" data-admin-cancel="${item.id}">取消</button>` : ""}</td>
              </tr>`;
          }).join("")}
        </tbody>
      </table>
    </div>`;

  holder.querySelectorAll("[data-admin-cancel]").forEach((button) => {
    button.addEventListener("click", () => cancelBooking(Number(button.dataset.adminCancel), () => loadAdminBookings(false)));
  });
}
