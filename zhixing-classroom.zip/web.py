"""HTTP 层：JSON API、静态资源与会话 Cookie。"""

from __future__ import annotations

import hmac
import json
import mimetypes
import os
import re
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler
from pathlib import Path

import database
import services
from services import ApiError

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
COOKIE_NAME = "classroom_session"
MAX_BODY = 1_000_000

ID_ROUTE = re.compile(r"^/api/(courses|classrooms|bookings)/(\d+)$")


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "ZhixingClassroom/1.0"
    protocol_version = "HTTP/1.1"

    # ------------------------------------------------------------------
    # 请求入口
    # ------------------------------------------------------------------

    def do_GET(self) -> None:  # noqa: N802
        self._dispatch("GET")

    def do_POST(self) -> None:  # noqa: N802
        self._dispatch("POST")

    def do_PUT(self) -> None:  # noqa: N802
        self._dispatch("PUT")

    def do_DELETE(self) -> None:  # noqa: N802
        self._dispatch("DELETE")

    def _dispatch(self, method: str) -> None:
        parsed = urllib.parse.urlsplit(self.path)
        path = urllib.parse.unquote(parsed.path)
        query = urllib.parse.parse_qs(parsed.query)
        try:
            if path.startswith("/api/"):
                self._handle_api(method, path, query)
            elif method == "GET":
                self._serve_static(path)
            else:
                self._send_json(405, {"error": "不支持的请求方法"})
        except ApiError as exc:
            self._send_json(
                exc.status, {"error": exc.message, **({"details": exc.details} if exc.details else {})}
            )
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception:
            traceback.print_exc()
            self._send_json(500, {"error": "服务器开小差了，请稍后重试"})

    # ------------------------------------------------------------------
    # API
    # ------------------------------------------------------------------

    def _handle_api(self, method: str, path: str, query: dict) -> None:
        if path == "/api/health" and method == "GET":
            self._send_json(200, {"ok": True, "service": "zhixing-classroom"})
            return

        body = self._read_body() if method in ("POST", "PUT", "DELETE") else {}
        conn = database.connect()
        try:
            if path == "/api/login" and method == "POST":
                username = body.get("username", "")
                password = body.get("password", "")
                user = services.authenticate(conn, username, password)
                token = services.create_session(user["id"])
                csrf = services.csrf_for_session(token)
                self._send_json(
                    200,
                    {
                        "user": user,
                        "csrf": csrf,
                        "meta": services.get_meta(conn),
                    },
                    extra_headers=[self._session_cookie(token)],
                )
                return

            user, session = services.read_session(conn, self._session_token())
            if not user or not session:
                raise ApiError("登录状态已失效，请重新登录", 401)

            if method in ("POST", "PUT", "DELETE"):
                self._verify_csrf(session)

            if path == "/api/me" and method == "GET":
                self._send_json(200, {"user": user, "csrf": services.csrf_for_session(session)})
                return

            if path == "/api/logout" and method == "POST":
                self._send_json(
                    200,
                    {"ok": True},
                    extra_headers=[f"{COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"],
                )
                return

            if path == "/api/meta" and method == "GET":
                self._send_json(200, services.get_meta(conn))
                return

            if path == "/api/overview" and method == "GET":
                date_value = _first(query, "date")
                at_value = _first(query, "at")
                self._send_json(200, services.get_overview(conn, date_value, at_value, user))
                return

            if path == "/api/schedule" and method == "GET":
                self._send_json(200, services.get_schedule(conn, user))
                return

            if path == "/api/courses" and method == "GET":
                self._send_json(200, {"courses": services.list_courses(conn, user)})
                return

            if path == "/api/courses" and method == "POST":
                self._send_json(201, {"course": services.create_course(conn, user, body)})
                return

            if path == "/api/classrooms" and method == "GET":
                self._send_json(200, {"classrooms": services.list_classrooms(conn, user)})
                return

            if path == "/api/classrooms" and method == "POST":
                self._send_json(201, {"classroom": services.create_classroom(conn, user, body)})
                return

            if path == "/api/bookings" and method == "GET":
                self._send_json(200, {"bookings": services.list_bookings(conn, user)})
                return

            if path == "/api/bookings" and method == "POST":
                self._send_json(201, {"booking": services.create_booking(conn, user, body)})
                return

            if path == "/api/settings" and method == "GET":
                self._send_json(200, services.semester_info(conn))
                return

            if path == "/api/settings" and method == "PUT":
                semester = services.update_semester(conn, user, body)
                self._send_json(200, {"semester": semester})
                return

            match = ID_ROUTE.match(path)
            if match:
                resource, raw_id = match.groups()
                item_id = int(raw_id)
                if resource == "courses":
                    if method == "PUT":
                        self._send_json(
                            200, {"course": services.update_course(conn, user, item_id, body)}
                        )
                        return
                    if method == "DELETE":
                        services.delete_course(conn, user, item_id)
                        self._send_json(200, {"ok": True})
                        return
                if resource == "classrooms":
                    if method == "PUT":
                        self._send_json(
                            200,
                            {"classroom": services.update_classroom(conn, user, item_id, body)},
                        )
                        return
                if resource == "bookings":
                    if method == "DELETE":
                        self._send_json(
                            200, {"booking": services.cancel_booking(conn, user, item_id)}
                        )
                        return

            raise ApiError("接口不存在", 404)
        finally:
            conn.close()

    def _read_body(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            raise ApiError("请求体格式不正确")
        if length > MAX_BODY:
            raise ApiError("请求体过大", 413)
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ApiError("请求体必须是合法的 JSON")
        if not isinstance(data, dict):
            raise ApiError("请求体格式不正确")
        return data

    # ------------------------------------------------------------------
    # 响应
    # ------------------------------------------------------------------

    def _send_json(self, status: int, payload: dict, extra_headers: list[str] | None = None) -> None:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self._security_headers()
        for header in extra_headers or []:
            self.send_header("Set-Cookie", header)
        self.end_headers()
        self.wfile.write(data)

    def _serve_static(self, path: str) -> None:
        if path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        if path in ("/", "/index.html"):
            file_path = STATIC_DIR / "index.html"
        elif path.startswith("/static/"):
            relative = path[len("/static/") :]
            file_path = (STATIC_DIR / relative).resolve()
            if STATIC_DIR.resolve() not in file_path.parents:
                self._send_json(403, {"error": "禁止访问"})
                return
        else:
            self._send_json(404, {"error": "页面不存在"})
            return

        if not file_path.is_file():
            self._send_json(404, {"error": "资源不存在"})
            return

        mime, _ = mimetypes.guess_type(file_path.name)
        if file_path.suffix == ".js":
            mime = "text/javascript; charset=utf-8"
        elif file_path.suffix == ".css":
            mime = "text/css; charset=utf-8"
        elif file_path.suffix == ".html":
            mime = "text/html; charset=utf-8"
        elif mime and mime.startswith("text/"):
            mime += "; charset=utf-8"
        else:
            mime = mime or "application/octet-stream"

        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header(
            "Cache-Control",
            "no-cache" if file_path.suffix == ".html" else "public, max-age=3600",
        )
        self._security_headers()
        self.end_headers()
        self.wfile.write(data)

    def _security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
            "script-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'",
        )

    # ------------------------------------------------------------------
    # Cookie / CSRF
    # ------------------------------------------------------------------

    def _session_token(self) -> str | None:
        raw = self.headers.get("Cookie")
        if not raw:
            return None
        for part in raw.split(";"):
            name, _, value = part.strip().partition("=")
            if name == COOKIE_NAME:
                return value
        return None

    def _session_cookie(self, token: str) -> str:
        return (
            f"{COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Lax; "
            f"Max-Age={services.SESSION_TTL}"
        )

    def _verify_csrf(self, session: str) -> None:
        expected = services.csrf_for_session(session)
        supplied = self.headers.get("X-CSRF-Token", "")
        if not supplied or not hmac.compare_digest(supplied, expected):
            raise ApiError("安全校验失败，请刷新页面后重试", 403)

    # ------------------------------------------------------------------
    # 日志
    # ------------------------------------------------------------------

    def log_message(self, format: str, *args) -> None:  # noqa: A002
        if os.environ.get("CLASSROOM_DEBUG"):
            super().log_message(format, *args)


def _first(query: dict, key: str) -> str | None:
    values = query.get(key)
    return values[0] if values else None
