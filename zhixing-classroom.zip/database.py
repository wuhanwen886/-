"""SQLite 数据层：建表、演示数据与密码工具。"""

from __future__ import annotations

import hashlib
import os
import secrets
import sqlite3
from datetime import date, timedelta
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

_db_path: Path | None = None
_secret: bytes | None = None


def set_db_path(path: str | Path) -> None:
    """供测试或多实例部署时覆盖数据库位置。"""
    global _db_path
    _db_path = Path(path).resolve()


def get_db_path() -> Path:
    if _db_path is not None:
        return _db_path
    env_path = os.environ.get("CLASSROOM_DB")
    if env_path:
        return Path(env_path).expanduser().resolve()
    return BASE_DIR / "data" / "classroom.db"


def connect() -> sqlite3.Connection:
    path = get_db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    return conn


def get_secret() -> bytes:
    """用于签名登录 Cookie 与 CSRF Token 的持久化密钥。"""
    global _secret
    if _secret is not None:
        return _secret

    env_secret = os.environ.get("CLASSROOM_SECRET")
    if env_secret:
        _secret = env_secret.encode("utf-8")
        return _secret

    path = get_db_path().parent / "session.key"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        _secret = path.read_bytes()
    else:
        _secret = secrets.token_bytes(32)
        path.write_bytes(_secret)
    return _secret


def hash_password(password: str, salt_hex: str | None = None) -> tuple[str, str]:
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 180_000)
    return salt.hex(), digest.hex()


def verify_password(password: str, salt_hex: str, hash_hex: str) -> bool:
    salt = bytes.fromhex(salt_hex)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 180_000)
    return secrets.compare_digest(digest.hex(), hash_hex)


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    salt          TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('student', 'teacher', 'admin')),
    name          TEXT NOT NULL,
    identifier    TEXT,
    class_name    TEXT,
    created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS classrooms (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL UNIQUE,
    building   TEXT NOT NULL,
    room_no    TEXT NOT NULL,
    capacity   INTEGER NOT NULL CHECK (capacity > 0),
    room_type  TEXT NOT NULL,
    equipment  TEXT NOT NULL DEFAULT '',
    status     TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'maintenance')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (building, room_no)
);

CREATE TABLE IF NOT EXISTS courses (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    code         TEXT NOT NULL,
    name         TEXT NOT NULL,
    teacher_id   INTEGER NOT NULL REFERENCES users(id),
    classroom_id INTEGER NOT NULL REFERENCES classrooms(id),
    class_name   TEXT NOT NULL,
    weekday      INTEGER NOT NULL CHECK (weekday BETWEEN 1 AND 7),
    start_time   TEXT NOT NULL,
    end_time     TEXT NOT NULL,
    weeks_start  INTEGER NOT NULL CHECK (weeks_start BETWEEN 1 AND 30),
    weeks_end    INTEGER NOT NULL CHECK (weeks_end BETWEEN 1 AND 30),
    created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    classroom_id INTEGER NOT NULL REFERENCES classrooms(id),
    teacher_id   INTEGER NOT NULL REFERENCES users(id),
    date         TEXT NOT NULL,
    start_time   TEXT NOT NULL,
    end_time     TEXT NOT NULL,
    purpose      TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled')),
    created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    cancelled_at TEXT
);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_courses_weekday ON courses(weekday, teacher_id, classroom_id);
CREATE INDEX IF NOT EXISTS idx_bookings_date ON bookings(date, classroom_id, teacher_id);
CREATE INDEX IF NOT EXISTS idx_bookings_teacher ON bookings(teacher_id, date);
"""


def default_semester_start(today: date) -> date:
    if today.month >= 8:
        return date(today.year, 9, 1)
    if today.month <= 1:
        return date(today.year - 1, 9, 1)
    return date(today.year, 2, 20)


def semester_label(start: date) -> str:
    if start.month >= 8:
        return f"{start.year}-{start.year + 1} 学年 · 秋季学期"
    return f"{start.year - 1}-{start.year} 学年 · 春季学期"


def init_db() -> None:
    conn = connect()
    try:
        conn.executescript(SCHEMA)
        conn.commit()
        seed_demo_data(conn)
    finally:
        conn.close()


def _insert_user(
    conn: sqlite3.Connection,
    username: str,
    password: str,
    role: str,
    name: str,
    identifier: str,
    class_name: str | None = None,
) -> int:
    salt, digest = hash_password(password)
    cur = conn.execute(
        "INSERT INTO users (username, password_hash, salt, role, name, identifier, class_name) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (username, digest, salt, role, name, identifier, class_name),
    )
    return int(cur.lastrowid)


def seed_demo_data(conn: sqlite3.Connection) -> None:
    if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] > 0:
        return

    today = date.today()
    semester_start = default_semester_start(today)
    conn.executemany(
        "INSERT INTO settings (key, value) VALUES (?, ?)",
        [
            ("semester_start", semester_start.isoformat()),
            ("semester_name", semester_label(semester_start)),
        ],
    )

    _insert_user(conn, "admin", "123456", "admin", "周明", "A0001")
    teachers: dict[str, int] = {}
    for username, name, identifier in [
        ("teacher", "张伟", "T1001"),
        ("lina", "李娜", "T1002"),
        ("wangqiang", "王强", "T1003"),
    ]:
        teachers[username] = _insert_user(
            conn, username, "123456", "teacher", name, identifier
        )

    _insert_user(conn, "student", "123456", "student", "陈晨", "2023010101", "计算机2301")
    _insert_user(conn, "liuyang", "123456", "student", "刘洋", "2023010102", "计算机2301")
    _insert_user(conn, "zhaomin", "123456", "student", "赵敏", "2023020201", "软件2302")

    classrooms = [
        ("综合楼 A101", "综合楼", "A101", 120, "多媒体教室", "投影,音响,空调"),
        ("综合楼 A102", "综合楼", "A102", 80, "多媒体教室", "投影,空调"),
        ("综合楼 A201", "综合楼", "A201", 160, "阶梯教室", "双投影,音响,录播"),
        ("综合楼 A202", "综合楼", "A202", 60, "普通教室", "白板,空调"),
        ("教学楼 B101", "教学楼", "B101", 100, "多媒体教室", "投影,音响"),
        ("教学楼 B102", "教学楼", "B102", 60, "普通教室", "白板,空调"),
        ("教学楼 B201", "教学楼", "B201", 48, "研讨室", "圆桌,投屏,白板"),
        ("教学楼 B202", "教学楼", "B202", 48, "研讨室", "圆桌,投屏"),
        ("信息楼 C301", "信息楼", "C301", 60, "机房", "60台电脑,投影"),
        ("信息楼 C302", "信息楼", "C302", 60, "机房", "60台电脑,投影"),
        ("信息楼 C401", "信息楼", "C401", 40, "智慧教室", "录播,互动大屏,空调"),
        ("图书馆 D201", "图书馆", "D201", 30, "研讨室", "圆桌,投屏,白板"),
    ]
    conn.executemany(
        "INSERT INTO classrooms (name, building, room_no, capacity, room_type, equipment) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        classrooms,
    )
    room_ids = {
        row["name"]: row["id"]
        for row in conn.execute("SELECT id, name FROM classrooms").fetchall()
    }

    course_rows = [
        ("MATH101", "高等数学", "wangqiang", "教学楼 B102", "计算机2301", 1, "08:00", "09:35"),
        ("CS201", "数据结构", "teacher", "综合楼 A101", "计算机2301", 1, "10:05", "11:40"),
        ("PHY102", "大学物理", "lina", "教学楼 B101", "软件2302", 1, "14:00", "15:35"),
        ("CS101", "程序设计基础", "teacher", "信息楼 C301", "计算机2301", 1, "19:00", "20:35"),
        ("CS202", "操作系统", "lina", "综合楼 A102", "软件2302", 2, "08:00", "09:35"),
        ("CS201", "数据结构", "teacher", "综合楼 A101", "计算机2301", 2, "10:05", "11:40"),
        ("ENG101", "大学英语", "wangqiang", "教学楼 B101", "计算机2301", 2, "14:00", "15:35"),
        ("AI301", "人工智能导论", "teacher", "信息楼 C401", "计算机2301", 2, "16:05", "17:40"),
        ("CS203", "计算机网络", "lina", "教学楼 B101", "软件2302", 3, "08:00", "09:35"),
        ("MATH201", "线性代数", "wangqiang", "综合楼 A201", "计算机2301", 3, "10:05", "11:40"),
        ("CS204", "数据库原理", "teacher", "信息楼 C302", "计算机2301", 3, "14:00", "15:35"),
        ("CS205", "创新实践", "wangqiang", "教学楼 B201", "软件2302", 3, "19:00", "20:35"),
        ("SE301", "软件工程", "lina", "综合楼 A102", "软件2302", 4, "08:00", "09:35"),
        ("ENG102", "大学英语", "wangqiang", "教学楼 B102", "计算机2301", 4, "10:05", "11:40"),
        ("AI302", "机器学习", "teacher", "信息楼 C401", "计算机2301", 4, "14:00", "15:35"),
        ("CS206", "编译原理", "lina", "综合楼 A101", "软件2302", 5, "08:00", "09:35"),
        ("MATH202", "概率论与数理统计", "wangqiang", "综合楼 A201", "计算机2301", 5, "10:05", "11:40"),
        ("CS207", "课程设计", "teacher", "信息楼 C301", "计算机2301", 5, "14:00", "15:35"),
    ]
    for code, name, teacher, room, class_name, weekday, start, end in course_rows:
        conn.execute(
            "INSERT INTO courses "
            "(code, name, teacher_id, classroom_id, class_name, weekday, start_time, end_time, weeks_start, weeks_end) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 18)",
            (
                code,
                name,
                teachers[teacher],
                room_ids[room],
                class_name,
                weekday,
                start,
                end,
            ),
        )

    booking_rows = [
        ("综合楼 A201", "teacher", today, "12:10", "13:10", "课程组教学研讨"),
        ("教学楼 B201", "lina", today, "12:10", "13:10", "毕业设计答疑"),
        ("图书馆 D201", "wangqiang", today, "18:30", "20:00", "学科竞赛辅导"),
        (
            "综合楼 A101",
            "lina",
            today + timedelta(days=1),
            "19:00",
            "20:30",
            "算法兴趣小组集训",
        ),
    ]
    for room, teacher, booking_date, start, end, purpose in booking_rows:
        conn.execute(
            "INSERT INTO bookings "
            "(classroom_id, teacher_id, date, start_time, end_time, purpose, status) "
            "VALUES (?, ?, ?, ?, ?, ?, 'active')",
            (
                room_ids[room],
                teachers[teacher],
                booking_date.isoformat(),
                start,
                end,
                purpose,
            ),
        )

    conn.commit()
