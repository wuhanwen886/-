/* 教室实时总览。 */

import {
  $,
  $$,
  state,
  icon,
  esc,
  api,
  openModal,
  roomStateMeta,
  formatDateCN,
  formatShortDate,
  weekdayLabel,
  minutesToTime,
  timestampLabel,
  emptyState,
  pageSkeleton,
  suggestedBorrowRange,
  timeToMinutes as toMin,
} from "../core.js";
import { openBorrowModal } from "./booking.js";

const WINDOW_START = 480;
const WINDOW_END = 1320;
const WINDOW_SPAN = WINDOW_END - WINDOW_START;

function initFilters() {
  if (state.filters) return;
  const now = new Date();
  const current = now.getHours() * 60 + now.getMinutes();
  let at = "10:10";
  let followNow = false;
  if (current >= WINDOW_START && current < WINDOW_END) {
    at = minutesToTime(current);
    followNow = true;
  } else if (current >= WINDOW_END) {
    at = "19:00";
  }
  state.filters = {
    date: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`,
    at,
    building: "",
    capacity: "",
    status: "all",
    q: "",
  };
  state.followNow = followNow;
}

export async function renderOverviewPage(content) {
  initFilters();
  const filters = state.filters;

  content.innerHTML = `
    <div class="page-heading">
      <div>
        <div class="eyebrow">REAL-TIME CAMPUS</div>
        <h1>教室实时总览</h1>
        <p>查看各教学楼教室的占用情况与今日安排，数据每 10 秒自动刷新。</p>
      </div>
      <div class="heading-actions">
        <span class="live-pill"><span class="live-dot"></span>实时同步 <b id="last-update">--:--:--</b></span>
      </div>
    </div>

    <section class="filter-card">
      <div class="filter-grid">
        <label class="compact-field">
          <span>查看日期</span>
          <input type="date" id="filter-date" value="${filters.date}">
        </label>
        <label class="compact-field">
          <span>查询时间</span>
          <input type="time" id="filter-at" step="300" value="${filters.at}">
        </label>
        <label class="compact-field">
          <span>教学楼</span>
          <select id="filter-building">
            <option value="">全部楼栋</option>
            ${(state.meta.buildings || []).map((building) => `<option value="${esc(building)}" ${filters.building === building ? "selected" : ""}>${esc(building)}</option>`).join("")}
          </select>
        </label>
        <label class="compact-field">
          <span>容量</span>
          <select id="filter-capacity">
            <option value="">不限容量</option>
            <option value="40" ${filters.capacity === "40" ? "selected" : ""}>40 人以上</option>
            <option value="60" ${filters.capacity === "60" ? "selected" : ""}>60 人以上</option>
            <option value="100" ${filters.capacity === "100" ? "selected" : ""}>100 人以上</option>
          </select>
        </label>
        <label class="compact-field search-field">
          <span>搜索教室</span>
          <div class="search-input">${icon("search")}<input type="search" id="filter-q" placeholder="教室名称 / 楼栋 / 类型" value="${esc(filters.q)}"></div>
        </label>
        <button type="button" class="btn btn-ghost btn-now" id="btn-now">${icon("clock")}回到现在</button>
      </div>
      <div class="filter-bottom">
        <div class="segmented" id="status-segments" role="group" aria-label="教室状态筛选">
          <button type="button" class="segment ${filters.status === "all" ? "is-active" : ""}" data-status="all">全部</button>
          <button type="button" class="segment ${filters.status === "free" ? "is-active" : ""}" data-status="free">空闲中</button>
          <button type="button" class="segment ${filters.status === "busy" ? "is-active" : ""}" data-status="busy">使用中</button>
          <button type="button" class="segment ${filters.status === "maintenance" ? "is-active" : ""}" data-status="maintenance">维护中</button>
        </div>
        <div class="filter-count" id="result-count">正在读取教室数据…</div>
      </div>
    </section>

    <div id="overview-notice"></div>
    <section id="stats-area"></section>

    <div class="section-head">
      <div>
        <h2>教室状态 <span class="section-badge" id="week-badge"></span></h2>
        <p id="grid-subtitle">点击卡片查看当日完整时间轴</p>
      </div>
      <div class="legend">
        <span><i class="legend-dot course"></i>课程</span>
        <span><i class="legend-dot booking"></i>借用</span>
        <span><i class="legend-dot now"></i>查询时刻</span>
      </div>
    </div>
    <section class="room-grid" id="room-grid">${roomSkeleton(4)}</section>`;

  bindControls(content);
  await loadOverview(true);
  startPolling();
}

function bindControls(content) {
  const dateInput = $("#filter-date", content);
  const timeInput = $("#filter-at", content);
  const building = $("#filter-building", content);
  const capacity = $("#filter-capacity", content);
  const q = $("#filter-q", content);

  dateInput.addEventListener("change", () => {
    state.filters.date = dateInput.value || state.filters.date;
    state.followNow = false;
    loadOverview(true);
  });
  timeInput.addEventListener("change", () => {
    state.filters.at = timeInput.value || state.filters.at;
    state.followNow = false;
    loadOverview(false);
  });
  building.addEventListener("change", () => {
    state.filters.building = building.value;
    renderRooms();
  });
  capacity.addEventListener("change", () => {
    state.filters.capacity = capacity.value;
    renderRooms();
  });
  q.addEventListener("input", () => {
    state.filters.q = q.value.trim();
    renderRooms();
  });
  $("#btn-now", content).addEventListener("click", () => {
    const now = new Date();
    const current = now.getHours() * 60 + now.getMinutes();
    state.filters.date = localDate(now);
    state.filters.at = minutesToTime(current);
    state.followNow = true;
    dateInput.value = state.filters.date;
    timeInput.value = state.filters.at;
    loadOverview(false);
  });
  $$("#status-segments .segment", content).forEach((button) => {
    button.addEventListener("click", () => {
      state.filters.status = button.dataset.status;
      $$("#status-segments .segment", content).forEach((item) => item.classList.toggle("is-active", item === button));
      renderRooms();
    });
  });
}

function localDate(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function roomSkeleton(count = 4) {
  return `<div class="skeleton-grid">${Array.from({ length: count }, () => '<div class="skeleton sk-room"></div>').join("")}</div>`;
}

async function loadOverview(showSkeleton) {
  try {
    if (showSkeleton) {
      const statsArea = $("#stats-area");
      if (statsArea) {
        statsArea.innerHTML = `<div class="skeleton-stats">${Array.from({ length: 4 }, () => '<div class="skeleton sk-card"></div>').join("")}</div>`;
      }
      const grid = $("#room-grid");
      if (grid) grid.innerHTML = roomSkeleton(4);
    }
    const data = await api(`/overview?date=${encodeURIComponent(state.filters.date)}&at=${encodeURIComponent(state.filters.at)}`);
    if (state.page !== "overview") return;
    state.overview = data;
    state.filters.at = data.at;
    state.filters.date = data.date;
    $("#filter-at") && ($("#filter-at").value = data.at);
    $("#filter-date") && ($("#filter-date").value = data.date);
    renderStats();
    renderRooms();
    renderNotice();
    const last = $("#last-update");
    if (last) last.textContent = timestampLabel(data.server_time);
    const badge = $("#week-badge");
    if (badge) badge.textContent = data.week > 0 && data.week <= 30 ? `第 ${data.week} 教学周` : "非教学周";
  } catch (error) {
    const grid = $("#room-grid");
    if (grid) {
      grid.innerHTML = emptyState("alert", "读取失败", error.message, `<button class="btn btn-ghost" data-action="retry">${icon("refresh")}重新加载</button>`);
      grid.querySelector("[data-action='retry']")?.addEventListener("click", () => loadOverview(true));
    }
  }
}

function startPolling() {
  clearInterval(state.pollTimer);
  state.pollTimer = setInterval(async () => {
    if (state.page !== "overview" || document.hidden) return;
    if (state.followNow) {
      const now = new Date();
      const current = now.getHours() * 60 + now.getMinutes();
      if (current >= WINDOW_START && current < WINDOW_END) {
        state.filters.at = minutesToTime(current);
        const input = $("#filter-at");
        if (input && document.activeElement !== input) input.value = state.filters.at;
      }
    }
    await loadOverview(false);
  }, 10000);
}

function renderNotice() {
  const data = state.overview;
  const holder = $("#overview-notice");
  if (!data || !holder) return;
  const notices = [];
  const today = localDate(new Date());
  const current = new Date().getHours() * 60 + new Date().getMinutes();
  if (data.date !== today) {
    notices.push({
      tone: "info",
      icon: "calendar",
      text: `正在查看 ${formatDateCN(data.date)} 的教室安排，状态按所选时间 ${data.at} 计算。`,
    });
  } else if (data.outside_window) {
    if (state.followNow) {
      notices.push({
        tone: "warning",
        icon: "clock",
        text: `当前时间 ${data.at} 不在教学开放时段（08:00-22:00），教室状态按此刻计算。`,
      });
    } else {
      notices.push({
        tone: "info",
        icon: "clock",
        text: `所选时间 ${data.at} 不在教学开放时段（08:00-22:00），教室状态按该时刻计算。`,
      });
    }
  } else if (current < WINDOW_START || current >= WINDOW_END) {
    notices.push({
      tone: "info",
      icon: "clock",
      text: `当前不在教学开放时段，已为你展示最近教学时段 ${data.at} 的教室安排。点击「回到现在」可查看此刻状态。`,
    });
  }
  if (!data.semester.has_courses) {
    notices.push({
      tone: "warning",
      icon: "info",
      text: "当前日期不在学期教学周范围内，页面仅展示教师借用安排。",
    });
  }
  holder.innerHTML = notices
    .map(
      (notice) => `
      <div class="notice notice-${notice.tone}">
        <span class="notice-icon">${icon(notice.icon)}</span>
        <span>${esc(notice.text)}</span>
      </div>`
    )
    .join("");
}

function renderStats() {
  const data = state.overview;
  if (!data) return;
  const stats = data.stats;
  const freeRatio = stats.total ? Math.round((stats.free / stats.total) * 100) : 0;
  const isLiveNow = data.date === localDate(new Date()) && state.followNow && !data.outside_window;
  $("#stats-area").innerHTML = `
    <div class="stats-grid">
      <article class="stat-card stat-free">
        <div class="stat-icon">${icon("door")}</div>
        <div class="stat-body">
          <span class="stat-label">${isLiveNow ? "当前空闲" : "查询时段空闲"}</span>
          <div class="stat-value">${stats.free}<small>/ ${stats.total} 间</small></div>
          <div class="stat-meter"><span style="width:${freeRatio}%"></span></div>
          <p>可用教室占比 ${freeRatio}%</p>
        </div>
      </article>
      <article class="stat-card stat-busy">
        <div class="stat-icon">${icon("users")}</div>
        <div class="stat-body">
          <span class="stat-label">使用中</span>
          <div class="stat-value">${stats.busy}<small>间</small></div>
          <p>课程与教师借用占用</p>
        </div>
      </article>
      <article class="stat-card stat-book">
        <div class="stat-icon">${icon("clipboard")}</div>
        <div class="stat-body">
          <span class="stat-label">今日借用</span>
          <div class="stat-value">${stats.bookings_today}<small>条</small></div>
          <p>教师提交的有效借用</p>
        </div>
      </article>
      <article class="stat-card stat-muted">
        <div class="stat-icon">${icon("settings")}</div>
        <div class="stat-body">
          <span class="stat-label">维护中</span>
          <div class="stat-value">${stats.maintenance}<small>间</small></div>
          <p>维护教室暂不开放借用</p>
        </div>
      </article>
    </div>`;
}

function filteredRooms() {
  const data = state.overview;
  if (!data) return [];
  const filters = state.filters;
  return data.classrooms.filter((room) => {
    if (filters.building && room.building !== filters.building) return false;
    if (filters.capacity && room.capacity < Number(filters.capacity)) return false;
    if (filters.status !== "all" && room.state !== filters.status) return false;
    if (filters.q) {
      const haystack = `${room.name} ${room.building} ${room.room_type} ${room.equipment.join(" ")}`.toLowerCase();
      if (!haystack.includes(filters.q.toLowerCase())) return false;
    }
    return true;
  });
}

function renderRooms() {
  const data = state.overview;
  const grid = $("#room-grid");
  if (!data || !grid) return;
  const rooms = filteredRooms();
  const count = $("#result-count");
  if (count) {
    count.textContent = `共 ${data.classrooms.length} 间教室 · 当前显示 ${rooms.length} 间`;
  }
  const subtitle = $("#grid-subtitle");
  if (subtitle) {
    subtitle.textContent = `${formatShortDate(data.date)} ${weekdayLabel(data.date)} · ${data.at} 时刻 · 点击卡片查看完整时间轴`;
  }
  if (!rooms.length) {
    grid.innerHTML = emptyState(
      "search",
      "没有匹配的教室",
      "试试调整楼栋、容量或状态筛选条件。",
      `<button type="button" class="btn btn-ghost" data-action="reset-filters">${icon("refresh")}清除筛选</button>`
    );
    grid.querySelector("[data-action='reset-filters']")?.addEventListener("click", resetFilters);
    return;
  }
  grid.innerHTML = rooms.map((room) => roomCard(room, data)).join("");
  grid.onclick = (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const roomId = Number(button.dataset.room);
    if (button.dataset.action === "detail" || button.dataset.action === "card") {
      openRoomDetail(roomId);
    }
    if (button.dataset.action === "borrow") {
      const room = data.classrooms.find((item) => item.id === roomId);
      if (room) openBorrowFromOverview(room);
    }
  };
}

function resetFilters() {
  state.filters.building = "";
  state.filters.capacity = "";
  state.filters.status = "all";
  state.filters.q = "";
  $("#filter-building").value = "";
  $("#filter-capacity").value = "";
  $("#filter-q").value = "";
  $$("#status-segments .segment").forEach((item) => item.classList.toggle("is-active", item.dataset.status === "all"));
  renderRooms();
}

function roomCard(room, data) {
  const meta = roomStateMeta(room.state);
  const atMin = toMin(data.at);
  const equipment = room.equipment.slice(0, 2);
  let occupancy = "";
  if (room.state === "maintenance") {
    occupancy = `<div class="occupancy-note is-maintenance"><strong>维护中，暂停开放</strong><span>请联系管理员确认恢复时间</span></div>`;
  } else if (room.state === "busy") {
    occupancy = `
      <div class="occupancy-note is-busy">
        <div class="occupancy-title"><span class="now-badge">使用中</span><strong>${esc(room.current.title)}</strong></div>
        <span>${room.current.start} - ${room.current.end} · ${esc(room.current.subtitle)}</span>
      </div>`;
  } else {
    const nextText = room.upcoming
      ? `<span>下一场 ${room.upcoming.start} · ${esc(room.upcoming.title)}</span>`
      : `<span>今日后续暂无安排</span>`;
    const freeTitle =
      data.outside_window
        ? "非开放时段"
        : data.date === localDate(new Date()) && state.followNow
          ? "现在可以使用"
          : "该时段可以使用";
    occupancy = `
      <div class="occupancy-note is-free">
        <div class="occupancy-title"><span class="now-badge">空闲</span><strong>${freeTitle}</strong></div>
        ${nextText}
      </div>`;
  }

  return `
    <article class="room-card room-${room.state}" data-room-card="${room.id}">
      <div class="room-card-head">
        <div class="room-title-wrap">
          <div class="room-icon">${icon("door")}</div>
          <div>
            <h3>${esc(room.name)}</h3>
            <p>${esc(room.building)} · ${esc(room.room_type)}</p>
          </div>
        </div>
        <span class="status-pill status-${meta.tone}"><i></i>${meta.label}</span>
      </div>
      <div class="room-facts">
        <span>${icon("users")} ${room.capacity} 人</span>
        ${equipment.map((item) => `<span>${icon("monitor")} ${esc(item)}</span>`).join("")}
      </div>
      ${occupancy}
      <div class="mini-timeline-wrap">
        ${timelineMarkup(room, atMin)}
        <div class="timeline-scale"><span>08:00</span><span>15:00</span><span>22:00</span></div>
      </div>
      <div class="room-card-foot">
        <button type="button" class="link-btn" data-action="detail" data-room="${room.id}">查看安排 ${icon("arrow")}</button>
        ${
          state.user.role === "teacher"
            ? `<button type="button" class="btn btn-primary btn-sm" data-action="borrow" data-room="${room.id}" ${room.state === "maintenance" ? "disabled" : ""}>${icon("door")}借用</button>`
            : `<span class="room-id">ROOM ${String(room.id).padStart(2, "0")}</span>`
        }
      </div>
    </article>`;
}

function timelineMarkup(room, atMin, full = false) {
  const segments = room.intervals
    .map((item) => {
      const left = ((Math.max(WINDOW_START, item.start_min) - WINDOW_START) / WINDOW_SPAN) * 100;
      const width = ((Math.min(WINDOW_END, item.end_min) - Math.max(WINDOW_START, item.start_min)) / WINDOW_SPAN) * 100;
      return `<span class="tl-seg tl-${item.kind}" style="left:${left}%;width:${Math.max(width, 0.7)}%" title="${esc(`${item.start}-${item.end} ${item.title}`)}"></span>`;
    })
    .join("");
  const markerLeft = Math.min(100, Math.max(0, ((atMin - WINDOW_START) / WINDOW_SPAN) * 100));
  const marker = atMin >= WINDOW_START && atMin <= WINDOW_END
    ? `<i class="tl-now" style="left:${markerLeft}%" title="查询时刻 ${minutesToTime(atMin)}"></i>`
    : "";
  return `<div class="timeline ${full ? "timeline-full" : ""}"><div class="tl-track">${segments}${marker}</div></div>`;
}

function openRoomDetail(roomId) {
  const data = state.overview;
  const room = data?.classrooms.find((item) => item.id === roomId);
  if (!room) return;
  const meta = roomStateMeta(room.state);
  const atMin = toMin(data.at);
  const intervals = room.intervals || [];
  const list = intervals.length
    ? intervals
        .map(
          (item) => `
          <div class="schedule-row">
            <div class="schedule-time"><strong>${item.start}</strong><span>${item.end}</span></div>
            <div class="schedule-rail"><i class="rail-${item.kind}"></i></div>
            <div class="schedule-info">
              <strong>${esc(item.title)}</strong>
              <span>${esc(item.subtitle)}</span>
            </div>
            <span class="tag tag-${item.kind}">${item.kind === "course" ? "课程" : "借用"}</span>
          </div>`
        )
        .join("")
    : `<div class="detail-empty">${icon("calendar")}当天暂无课程或借用安排</div>`;

  const footer = `
    <button type="button" class="btn btn-ghost" data-close>关闭</button>
    ${
      state.user.role === "teacher" && room.state !== "maintenance"
        ? `<button type="button" class="btn btn-primary" data-borrow>${icon("door")}借用此教室</button>`
        : ""
    }`;

  const modal = openModal({
    title: room.name,
    subtitle: `${formatDateCN(data.date)} · ${data.at} 时刻`,
    size: "modal-md",
    body: `
      <div class="detail-head">
        <div class="detail-badges">
          <span class="status-pill status-${meta.tone}"><i></i>${meta.label}</span>
          <span class="soft-badge">${esc(room.room_type)}</span>
          <span class="soft-badge">${room.capacity} 人</span>
        </div>
        <span class="detail-room-code">ROOM ${String(room.id).padStart(2, "0")}</span>
      </div>
      <div class="detail-timeline-block">
        ${timelineMarkup(room, atMin, true)}
        <div class="timeline-scale"><span>08:00</span><span>12:00</span><span>16:00</span><span>20:00</span><span>22:00</span></div>
      </div>
      <div class="detail-section-head"><h3>当日安排</h3><span>${intervals.length} 项</span></div>
      <div class="schedule-list">${list}</div>
      <div class="detail-equipment">
        <span>教室设备</span>
        <div>${room.equipment.map((item) => `<em>${esc(item)}</em>`).join("") || "<em>暂无设备信息</em>"}</div>
      </div>`,
    footer,
  });

  modal.element.querySelector("[data-close]")?.addEventListener("click", () => modal.close());
  modal.element.querySelector("[data-borrow]")?.addEventListener("click", () => {
    modal.close();
    openBorrowFromOverview(room);
  });
}

function openBorrowFromOverview(room) {
  const data = state.overview;
  const range = suggestedBorrowRange(room, data.at);
  openBorrowModal(room, {
    date: data.date,
    start: range.start,
    end: range.end,
    onSuccess: () => loadOverview(false),
  });
}
