/* 管理员：课程管理。 */

import {
  $,
  $$,
  state,
  icon,
  esc,
  api,
  openModal,
  toast,
  confirmDialog,
  emptyState,
  formatDateCN,
  timeToMinutes,
  setButtonLoading,
  formError,
  clearFormError,
} from "../core.js";

const WEEKDAYS = [
  { value: 1, label: "周一" },
  { value: 2, label: "周二" },
  { value: 3, label: "周三" },
  { value: 4, label: "周四" },
  { value: 5, label: "周五" },
  { value: 6, label: "周六" },
  { value: 7, label: "周日" },
];

export async function renderCoursesPage(content) {
  state.courseFilters = state.courseFilters || { q: "", weekday: "all" };
  const semester = state.meta.semester;
  const weekLabel = semester.week > 0 && semester.week <= 30 ? `第 ${semester.week} 教学周` : "非教学周";

  content.innerHTML = `
    <div class="page-heading">
      <div>
        <div class="eyebrow">COURSE ADMIN</div>
        <h1>课程管理</h1>
        <p>维护课程、授课教师、教室与上课时间，排课冲突由系统自动校验。</p>
      </div>
      <div class="heading-actions">
        <button type="button" class="btn btn-ghost" data-action="semester">${icon("settings")}学期设置</button>
        <button type="button" class="btn btn-primary" data-action="add-course">${icon("plus")}添加课程</button>
      </div>
    </div>

    <section class="semester-banner">
      <div class="semester-main">
        <span class="semester-kicker">当前学期</span>
        <h2>${esc(semester.name)}</h2>
        <p>${formatDateCN(semester.start)} 开学 · ${weekLabel}</p>
      </div>
      <div class="semester-week">
        <span>教学进度</span>
        <strong>${semester.week > 0 && semester.week <= 30 ? semester.week : 0}<small>/ 18 周</small></strong>
        <div class="term-bar"><span style="width:${Math.min(100, Math.max(2, ((semester.week || 0) / 18) * 100))}%"></span></div>
      </div>
      <div class="semester-facts">
        <div><strong id="course-total">—</strong><span>门课程</span></div>
        <div><strong id="course-classes">—</strong><span>个授课班级</span></div>
      </div>
    </section>

    <section class="filter-card">
      <div class="filter-grid course-filter-grid">
        <label class="compact-field search-field">
          <span>搜索课程</span>
          <div class="search-input">${icon("search")}<input type="search" id="course-q" placeholder="课程名称 / 代码 / 教师 / 教室" value="${esc(state.courseFilters.q)}"></div>
        </label>
        <label class="compact-field">
          <span>上课星期</span>
          <select id="course-weekday">
            <option value="all">全部星期</option>
            ${WEEKDAYS.map((item) => `<option value="${item.value}" ${String(state.courseFilters.weekday) === String(item.value) ? "selected" : ""}>${item.label}</option>`).join("")}
          </select>
        </label>
      </div>
      <div class="filter-bottom">
        <div class="filter-count" id="course-count">正在载入课程…</div>
      </div>
    </section>

    <section class="table-card" id="course-table">
      <div class="page-loading-inline"><span class="spinner"></span>正在载入课程...</div>
    </section>`;

  $("[data-action='add-course']", content)?.addEventListener("click", () => openCourseModal());
  $("[data-action='semester']", content)?.addEventListener("click", openSemesterModal);
  $("#course-q", content)?.addEventListener("input", () => {
    state.courseFilters.q = $("#course-q").value.trim();
    renderCourseTable();
  });
  $("#course-weekday", content)?.addEventListener("change", () => {
    state.courseFilters.weekday = $("#course-weekday").value;
    renderCourseTable();
  });

  await loadCourses(true);
}

async function loadCourses(showLoading) {
  const holder = $("#course-table");
  if (!holder) return;
  if (showLoading) {
    holder.innerHTML = `<div class="page-loading-inline"><span class="spinner"></span>正在载入课程...</div>`;
  }
  try {
    const data = await api("/courses");
    if (state.page !== "courses") return;
    state.courses = data.courses;
    const total = $("#course-total");
    const classes = $("#course-classes");
    if (total) total.textContent = data.courses.length;
    if (classes) classes.textContent = new Set(data.courses.map((item) => item.class_name)).size;
    renderCourseTable();
  } catch (error) {
    holder.innerHTML = emptyState("alert", "读取失败", error.message);
  }
}

function renderCourseTable() {
  const holder = $("#course-table");
  if (!holder) return;
  const all = state.courses || [];
  const q = state.courseFilters.q.toLowerCase();
  const weekday = state.courseFilters.weekday;
  const rows = all.filter((course) => {
    if (weekday !== "all" && String(course.weekday) !== String(weekday)) return false;
    if (q) {
      const haystack = `${course.name} ${course.code} ${course.teacher_name} ${course.classroom_name} ${course.class_name}`.toLowerCase();
      if (!haystack.includes(q)) return false;
    }
    return true;
  });
  const count = $("#course-count");
  if (count) count.textContent = `共 ${all.length} 门课程 · 当前显示 ${rows.length} 门`;

  if (!rows.length) {
    holder.innerHTML = emptyState(
      "book",
      all.length ? "没有匹配的课程" : "还没有课程",
      all.length ? "试试调整搜索关键词或星期筛选。" : "点击右上角「添加课程」开始排课。",
      all.length ? "" : `<button type="button" class="btn btn-primary" data-empty-add>${icon("plus")}添加课程</button>`
    );
    holder.querySelector("[data-empty-add]")?.addEventListener("click", () => openCourseModal());
    return;
  }

  holder.innerHTML = `
    <div class="table-scroll">
      <table class="data-table course-table">
        <thead>
          <tr><th>课程</th><th>授课教师</th><th>班级</th><th>教室</th><th>上课时间</th><th>周次</th><th>操作</th></tr>
        </thead>
        <tbody>
          ${rows.map((course) => `
            <tr>
              <td>
                <div class="course-cell">
                  <span class="course-code">${esc(course.code)}</span>
                  <strong>${esc(course.name)}</strong>
                </div>
              </td>
              <td><div class="person-cell"><span class="avatar avatar-sm">${esc(course.teacher_name.slice(0, 1))}</span>${esc(course.teacher_name)}</div></td>
              <td><span class="soft-badge">${esc(course.class_name)}</span></td>
              <td><div class="room-cell"><strong>${esc(course.classroom_name)}</strong></div></td>
              <td>
                <div class="time-cell"><strong>${course.weekday_label} ${course.start_time} - ${course.end_time}</strong></div>
              </td>
              <td><span class="nowrap">${course.weeks_label}</span></td>
              <td>
                <div class="row-actions">
                  <button type="button" class="table-action" data-course-edit="${course.id}">${icon("edit")}编辑</button>
                  <button type="button" class="table-action danger" data-course-delete="${course.id}">${icon("trash")}删除</button>
                </div>
              </td>
            </tr>`).join("")}
        </tbody>
      </table>
    </div>`;

  holder.querySelectorAll("[data-course-edit]").forEach((button) => {
    button.addEventListener("click", () => {
      const course = all.find((item) => item.id === Number(button.dataset.courseEdit));
      if (course) openCourseModal(course);
    });
  });
  holder.querySelectorAll("[data-course-delete]").forEach((button) => {
    button.addEventListener("click", () => {
      const course = all.find((item) => item.id === Number(button.dataset.courseDelete));
      if (course) deleteCourse(course);
    });
  });
}

function openCourseModal(course = null) {
  const editing = Boolean(course);
  const teachers = state.meta.teachers || [];
  const classrooms = state.meta.classrooms || [];
  const week = state.meta.semester.week || 1;
  const values = course || {
    code: "",
    name: "",
    teacher_id: teachers[0]?.id || "",
    classroom_id: classrooms[0]?.id || "",
    class_name: "",
    weekday: 1,
    start_time: "08:00",
    end_time: "09:35",
    weeks_start: 1,
    weeks_end: 18,
  };

  const body = `
    <form id="course-form" class="stack-form" novalidate>
      <div class="form-error" role="alert"></div>
      <div class="form-section-label">基本信息</div>
      <div class="form-grid two">
        <label class="field">
          <span>课程代码</span>
          <input type="text" name="code" maxlength="24" value="${esc(values.code)}" placeholder="例如 CS201" autofocus required>
        </label>
        <label class="field">
          <span>课程名称</span>
          <input type="text" name="name" maxlength="60" value="${esc(values.name)}" placeholder="例如 数据结构" required>
        </label>
        <label class="field">
          <span>授课教师</span>
          <select name="teacher_id" required>
            ${teachers.map((teacher) => `<option value="${teacher.id}" ${Number(values.teacher_id) === teacher.id ? "selected" : ""}>${esc(teacher.name)} · ${esc(teacher.identifier || "")}</option>`).join("")}
          </select>
        </label>
        <label class="field">
          <span>授课班级</span>
          <input type="text" name="class_name" maxlength="40" value="${esc(values.class_name)}" placeholder="例如 计算机2301" required>
        </label>
      </div>

      <div class="form-section-label">上课安排</div>
      <div class="form-grid two">
        <label class="field">
          <span>教室</span>
          <select name="classroom_id" required>
            ${classrooms.map((room) => `<option value="${room.id}" ${Number(values.classroom_id) === room.id ? "selected" : ""}>${esc(room.name)} · ${room.capacity}人${room.status === "maintenance" ? "（维护中）" : ""}</option>`).join("")}
          </select>
        </label>
        <label class="field">
          <span>上课星期</span>
          <select name="weekday" required>
            ${WEEKDAYS.map((day) => `<option value="${day.value}" ${Number(values.weekday) === day.value ? "selected" : ""}>${day.label}</option>`).join("")}
          </select>
        </label>
        <label class="field">
          <span>开始时间</span>
          <input type="time" name="start_time" step="300" value="${values.start_time}" required>
        </label>
        <label class="field">
          <span>结束时间</span>
          <input type="time" name="end_time" step="300" value="${values.end_time}" required>
        </label>
        <label class="field">
          <span>起始教学周</span>
          <input type="number" name="weeks_start" min="1" max="30" value="${values.weeks_start}" required>
        </label>
        <label class="field">
          <span>结束教学周</span>
          <input type="number" name="weeks_end" min="1" max="30" value="${values.weeks_end}" required>
        </label>
      </div>

      <div class="form-note">${icon("info")}系统会自动检查教室冲突、教师冲突、班级冲突，以及该时段已有的教师借用。当前演示数据为第 ${week} 教学周。</div>
    </form>`;

  const modal = openModal({
    title: editing ? "编辑课程" : "添加课程",
    subtitle: editing ? `${course.name} · ${course.code}` : "新建一门课程并安排固定上课时间",
    size: "modal-lg",
    body,
    footer: `
      <button type="button" class="btn btn-ghost" data-cancel>取消</button>
      <button type="submit" class="btn btn-primary" form="course-form" data-submit>${icon("check")}${editing ? "保存修改" : "创建课程"}</button>`,
  });

  const form = modal.element.querySelector("#course-form");
  const submit = modal.element.querySelector("[data-submit]");
  modal.element.querySelector("[data-cancel]")?.addEventListener("click", () => modal.close());
  form?.addEventListener("input", () => clearFormError(form));

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearFormError(form);
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());
    const startMin = timeToMinutes(payload.start_time);
    const endMin = timeToMinutes(payload.end_time);
    if (!payload.code.trim() || !payload.name.trim() || !payload.class_name.trim()) {
      formError(form, "请填写课程代码、课程名称和授课班级");
      return;
    }
    if (endMin <= startMin) {
      formError(form, "结束时间必须晚于开始时间");
      return;
    }
    if (startMin < 480 || endMin > 1320) {
      formError(form, "课程时间需在 08:00-22:00 之间");
      return;
    }
    if (Number(payload.weeks_end) < Number(payload.weeks_start)) {
      formError(form, "结束周不能早于起始周");
      return;
    }

    setButtonLoading(submit, true, "保存中...");
    try {
      const endpoint = editing ? `/courses/${course.id}` : "/courses";
      await api(endpoint, {
        method: editing ? "PUT" : "POST",
        body: {
          code: payload.code.trim(),
          name: payload.name.trim(),
          teacher_id: Number(payload.teacher_id),
          classroom_id: Number(payload.classroom_id),
          class_name: payload.class_name.trim(),
          weekday: Number(payload.weekday),
          start_time: payload.start_time,
          end_time: payload.end_time,
          weeks_start: Number(payload.weeks_start),
          weeks_end: Number(payload.weeks_end),
        },
      });
      modal.close(true);
      toast(editing ? "课程信息已更新" : "课程已创建");
      await loadCourses(false);
    } catch (error) {
      formError(form, error.message);
      setButtonLoading(submit, false);
    }
  });
}

async function deleteCourse(course) {
  const confirmed = await confirmDialog({
    title: "删除课程",
    message: `确定删除《${course.name}》（${course.code}）吗？删除后该时段将重新开放。`,
    confirmText: "删除课程",
    danger: true,
  });
  if (!confirmed) return;
  try {
    await api(`/courses/${course.id}`, { method: "DELETE" });
    toast("课程已删除");
    await loadCourses(false);
  } catch (error) {
    toast(error.message, "error");
  }
}

function openSemesterModal() {
  const semester = state.meta.semester;
  const body = `
    <form id="semester-form" class="stack-form" novalidate>
      <div class="form-error" role="alert"></div>
      <label class="field">
        <span>学期名称</span>
        <input type="text" name="name" maxlength="60" value="${esc(semester.name)}" autofocus required>
      </label>
      <label class="field">
        <span>学期开始日期（所在周的周一）</span>
        <input type="date" name="start" value="${semester.start}" required>
        <small class="field-hint">教学周将根据该日期重新计算，已有课程按周次继续生效。</small>
      </label>
      <div class="form-note">${icon("alert")}调整学期日期会改变当前教学周，请确认后再保存。</div>
    </form>`;

  const modal = openModal({
    title: "学期设置",
    subtitle: "设置当前学期名称与教学周起点",
    size: "modal-md",
    body,
    footer: `
      <button type="button" class="btn btn-ghost" data-cancel>取消</button>
      <button type="submit" class="btn btn-primary" form="semester-form" data-submit>${icon("check")}保存设置</button>`,
  });

  const form = modal.element.querySelector("#semester-form");
  const submit = modal.element.querySelector("[data-submit]");
  modal.element.querySelector("[data-cancel]")?.addEventListener("click", () => modal.close());
  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearFormError(form);
    const data = Object.fromEntries(new FormData(form).entries());
    if (!data.name.trim() || !data.start) {
      formError(form, "请填写学期名称和开始日期");
      return;
    }
    setButtonLoading(submit, true, "保存中...");
    try {
      const result = await api("/settings", {
        method: "PUT",
        body: { name: data.name.trim(), start: data.start },
      });
      state.meta.semester = result.semester;
      toast("学期设置已更新");
      modal.close(true);
      setTimeout(() => location.reload(), 350);
    } catch (error) {
      formError(form, error.message);
      setButtonLoading(submit, false);
    }
  });
}
