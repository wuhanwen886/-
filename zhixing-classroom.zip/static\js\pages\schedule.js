/* 学生 / 教师：本周课表。 */

import {
  $,
  state,
  icon,
  esc,
  api,
  openModal,
  emptyState,
  formatDateCN,
  minutesToTime,
} from "../core.js";

const START_MIN = 480;
const END_MIN = 1320;
const SPAN = END_MIN - START_MIN;

export async function renderSchedulePage(content) {
  const isTeacher = state.user.role === "teacher";
  content.innerHTML = `
    <div class="page-heading">
      <div>
        <div class="eyebrow">WEEKLY SCHEDULE</div>
        <h1>${isTeacher ? "我的授课课表" : "我的课表"}</h1>
        <p>${isTeacher ? "查看本周授课安排与教室分布。" : "查看本班本周课程与上课教室。"}</p>
      </div>
      <div class="heading-actions">
        <span class="live-pill live-pill-static">${icon("calendar")}${esc(state.meta.semester.name)}</span>
      </div>
    </div>
    <div id="schedule-stats" class="stats-grid stats-grid-mini"></div>
    <div id="schedule-body">
      <div class="page-loading-inline"><span class="spinner"></span>正在生成课表...</div>
    </div>`;

  await loadSchedule();
}

async function loadSchedule() {
  try {
    const data = await api("/schedule");
    if (state.page !== "schedule") return;
    state.schedule = data;
    renderScheduleStats(data);
    renderSchedule(data);
  } catch (error) {
    $("#schedule-body").innerHTML = emptyState("alert", "课表读取失败", error.message);
  }
}

function renderScheduleStats(data) {
  const holder = $("#schedule-stats");
  if (!holder) return;
  holder.innerHTML = `
    <article class="stat-card stat-free stat-card-horizontal">
      <div class="stat-icon">${icon("book")}</div>
      <div class="stat-body"><span class="stat-label">本周课程</span><div class="stat-value">${data.stats.course_count}<small>门</small></div></div>
    </article>
    <article class="stat-card stat-busy stat-card-horizontal">
      <div class="stat-icon">${icon("calendar")}</div>
      <div class="stat-body"><span class="stat-label">今日课程</span><div class="stat-value">${data.stats.today_count}<small>节</small></div></div>
    </article>
    <article class="stat-card stat-book stat-card-horizontal">
      <div class="stat-icon">${icon("clock")}</div>
      <div class="stat-body"><span class="stat-label">本周课时</span><div class="stat-value">${data.stats.weekly_hours}<small>小时</small></div></div>
    </article>
    <article class="stat-card stat-muted stat-card-horizontal">
      <div class="stat-icon">${icon("pin")}</div>
      <div class="stat-body"><span class="stat-label">教学周</span><div class="stat-value">${data.semester.week > 0 ? data.semester.week : "—"}<small>/ 18 周</small></div></div>
    </article>`;
}

function renderSchedule(data) {
  const holder = $("#schedule-body");
  if (!holder) return;
  const courses = data.courses || [];
  const todayDay = data.days.find((day) => day.is_today)?.weekday || null;
  const todayCourses = (todayDay ? courses.filter((course) => course.weekday === todayDay) : [])
    .sort((a, b) => a.start_time.localeCompare(b.start_time));

  const side = `
    <aside class="schedule-side">
      <section class="side-card">
        <div class="side-card-head">
          <h3>今日课程</h3>
          <span>${formatDateCN(data.today)}</span>
        </div>
        ${todayCourses.length ? `
          <div class="today-list">
            ${todayCourses.map((course) => `
              <button type="button" class="today-item" data-course-id="${course.id}">
                <span class="today-time">${course.start_time}<em>${course.end_time}</em></span>
                <span class="today-line"></span>
                <span class="today-copy">
                  <strong>${esc(course.name)}</strong>
                  <small>${esc(course.classroom_name)} · ${esc(course.teacher_name)}</small>
                </span>
              </button>`).join("")}
          </div>` : `<div class="side-empty">${icon("clock")}<p>今天没有课程安排</p><span>享受一段自主安排的时间</span></div>`}
      </section>

      <section class="side-card term-side-card">
        <span class="semester-kicker">CURRENT SEMESTER</span>
        <h3>${esc(data.semester.name)}</h3>
        <p>当前为第 ${data.semester.week > 0 ? data.semester.week : "—"} 教学周</p>
        <div class="term-progress"><span style="width:${Math.min(100, Math.max(2, ((data.semester.week || 0) / 18) * 100))}%"></span></div>
        <div class="term-side-foot"><span>学期开始</span><strong>${formatDateCN(data.semester.start, false)}</strong></div>
      </section>
    </aside>`;

  if (!courses.length) {
    holder.innerHTML = `
      <div class="schedule-empty-layout">
        ${emptyState("calendar", "本周暂无课程", "当前教学周内没有排课安排，可前往教室总览查看空闲教室。")}
        ${side}
      </div>`;
    bindScheduleEvents(holder, data);
    return;
  }

  const hours = [8, 10, 12, 14, 16, 18, 20, 22];
  const board = `
    <section class="calendar-card">
      <div class="calendar-head">
        <div>
          <h2>本周课表</h2>
          <p>${esc(data.semester.name)} · 第 ${data.semester.week > 0 ? data.semester.week : "—"} 教学周</p>
        </div>
        <div class="calendar-legend">
          <span><i class="legend-dot course"></i>课程</span>
          <span><i class="legend-dot now"></i>当前时间</span>
        </div>
      </div>
      <div class="week-board-scroll">
        <div class="week-board">
          <div class="week-head">
            <div class="week-corner">时间</div>
            ${data.days.map((day) => `
              <div class="week-day-head ${day.is_today ? "is-today" : ""}">
                <span>${day.label}</span>
                <strong>${day.month}/${day.day}</strong>
              </div>`).join("")}
          </div>
          <div class="week-grid-body">
            <div class="week-time-axis">
              ${hours.map((hour) => `<span style="top:${((hour * 60 - START_MIN) / SPAN) * 100}%">${String(hour).padStart(2, "0")}:00</span>`).join("")}
            </div>
            ${data.days.map((day) => {
              const dayCourses = courses.filter((course) => course.weekday === day.weekday);
              const now = new Date();
              const nowLine = day.is_today && now.getHours() * 60 + now.getMinutes() >= START_MIN && now.getHours() * 60 + now.getMinutes() < END_MIN
                ? `<i class="week-now-line" style="top:${((now.getHours() * 60 + now.getMinutes() - START_MIN) / SPAN) * 100}%"><span>${minutesToTime(now.getHours() * 60 + now.getMinutes())}</span></i>`
                : "";
              return `
                <div class="week-day-lane ${day.is_today ? "is-today" : ""}">
                  ${dayCourses.map((course) => courseBlock(course)).join("")}
                  ${nowLine}
                </div>`;
            }).join("")}
          </div>
        </div>
      </div>
    </section>`;

  holder.innerHTML = `<div class="schedule-layout"><div class="schedule-main">${board}</div>${side}</div>`;
  bindScheduleEvents(holder, data);
}

function courseBlock(course) {
  const start = Number(course.start_time.split(":")[0]) * 60 + Number(course.start_time.split(":")[1]);
  const end = Number(course.end_time.split(":")[0]) * 60 + Number(course.end_time.split(":")[1]);
  const top = ((Math.max(START_MIN, start) - START_MIN) / SPAN) * 100;
  const height = ((Math.min(END_MIN, end) - Math.max(START_MIN, start)) / SPAN) * 100;
  const compact = end - start < 75;
  return `
    <button type="button" class="timetable-block ${compact ? "is-compact" : ""}" style="top:${top}%;height:${height}%" data-course-id="${course.id}" title="${esc(`${course.name} ${course.start_time}-${course.end_time}`)}">
      <span class="block-time">${course.start_time} - ${course.end_time}</span>
      <strong>${esc(course.name)}</strong>
      <span class="block-room">${icon("pin")}${esc(course.classroom_name)}</span>
      ${compact ? "" : `<small>${esc(course.teacher_name)} · ${esc(course.class_name)}</small>`}
    </button>`;
}

function bindScheduleEvents(holder, data) {
  holder.addEventListener("click", (event) => {
    const target = event.target.closest("[data-course-id]");
    if (!target) return;
    const course = (data.courses || []).find((item) => item.id === Number(target.dataset.courseId));
    if (course) openCourseDetail(course, data);
  });
}

function openCourseDetail(course, data) {
  openModal({
    title: course.name,
    subtitle: `${course.code} · ${course.weekday_label}`,
    size: "modal-sm",
    body: `
      <div class="course-detail-hero">
        <span class="course-detail-code">${esc(course.code)}</span>
        <h3>${esc(course.name)}</h3>
        <p>${esc(course.weeks_label)} · ${course.start_time} - ${course.end_time}</p>
      </div>
      <div class="detail-info-list">
        <div><span>${icon("user")}授课教师</span><strong>${esc(course.teacher_name)}</strong></div>
        <div><span>${icon("users")}授课班级</span><strong>${esc(course.class_name)}</strong></div>
        <div><span>${icon("pin")}上课教室</span><strong>${esc(course.classroom_name)}</strong></div>
        <div><span>${icon("calendar")}上课时间</span><strong>${course.weekday_label} ${course.start_time} - ${course.end_time}</strong></div>
      </div>
      <div class="form-note">${icon("info")}课程信息由教务管理员维护，如有调整请联系管理员。</div>`,
    footer: `<button type="button" class="btn btn-ghost" data-close>关闭</button>`,
    onMount(element, close) {
      element.querySelector("[data-close]").addEventListener("click", () => close());
    },
  });
}
