@echo off
setlocal
cd /d "%~dp0"

set "DSH_PY=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe"
if exist "%DSH_PY%" (
    "%DSH_PY%" app.py %*
    goto :end
)

where py >nul 2>nul
if not errorlevel 1 (
    py -3 app.py %*
    goto :end
)

where python >nul 2>nul
if not errorlevel 1 (
    python app.py %*
    goto :end
)

echo.
echo [ERROR] Python 3.10+ was not found.
echo Install Python from https://www.python.org/downloads/ and try again.
echo.
pause

:end
endlocal
