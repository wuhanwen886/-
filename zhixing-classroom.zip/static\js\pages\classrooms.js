/* 管理员：教室档案管理。 */

import {
  $,
  state,
  icon,
  esc,
  api,
  loadMeta,
  openModal,
  toast,
  emptyState,
  setButtonLoading,
  formError,
  clearFormError,
} from "../core.js";

export async function renderClassroomsPage(content) {
  state.classroomFilters = state.classroomFilters || { q: "", building: "", status: "all" };
  const filters = state.classroomFilters;

  content.innerHTML = `
    <div class="page-heading">
      <div>
        <div class="eyebrow">CLASSROOM ADMIN</div>
        <h1>教室管理</h1>
        <p>维护教室容量、类型与设备信息，并控制教室的开放状态。</p>
      </div>
      <div class="heading-actions">
        <button type="button" class="btn btn-primary" data-action="add-classroom">${icon("plus")}新增教室</button>
      </div>
    </div>

    <div id="classroom-stats" class="stats-grid stats-grid-mini"></div>

    <section class="filter-card">
      <div class="classroom-filter-grid">
        <label class="compact-field search-field">
          <span>搜索教室</span>
          <div class="search-input">${icon("search")}<input type="search" id="classroom-q" placeholder="教室名称 / 房间号 / 设备" value="${esc(filters.q)}"></div>
        </label>
        <label class="compact-field">
          <span>所属楼栋</span>
          <select id="classroom-building">
            <option value="">全部楼栋</option>
            ${(state.meta.buildings || []).map((building) => `<option value="${esc(building)}" ${filters.building === building ? "selected" : ""}>${esc(building)}</option>`).join("")}
          </select>
        </label>
        <label class="compact-field">
          <span>开放状态</span>
          <select id="classroom-status">
            <option value="all">全部状态</option>
            <option value="active" ${filters.status === "active" ? "selected" : ""}>开放中</option>
            <option value="maintenance" ${filters.status === "maintenance" ? "selected" : ""}>维护中</option>
          </select>
        </label>
      </div>
      <div class="filter-bottom">
        <div class="filter-count" id="classroom-count">正在载入教室...</div>
      </div>
    </section>

    <section class="classroom-admin-grid" id="classroom-grid">
      <div class="page-loading-inline"><span class="spinner"></span>正在载入教室...</div>
    </section>`;

  $("[data-action='add-classroom']", content)?.addEventListener("click", () => openClassroomModal());
  $("#classroom-q", content)?.addEventListener("input", () => {
    state.classroomFilters.q = $("#classroom-q").value.trim();
    renderClassroomGrid();
  });
  $("#classroom-building", content)?.addEventListener("change", () => {
    state.classroomFilters.building = $("#classroom-building").value;
    renderClassroomGrid();
  });
  $("#classroom-status", content)?.addEventListener("change", () => {
    state.classroomFilters.status = $("#classroom-status").value;
    renderClassroomGrid();
  });

  await loadClassrooms(true);
}

async function loadClassrooms(showLoading) {
  const holder = $("#classroom-grid");
  if (!holder) return;
  if (showLoading) {
    holder.innerHTML = `<div class="page-loading-inline"><span class="spinner"></span>正在载入教室...</div>`;
  }
  try {
    const data = await api("/classrooms");
    if (state.page !== "classrooms") return;
    state.classrooms = data.classrooms;
    renderClassroomStats();
    renderClassroomGrid();
  } catch (error) {
    holder.innerHTML = emptyState("alert", "读取失败", error.message);
  }
}

function renderClassroomStats() {
  const holder = $("#classroom-stats");
  if (!holder) return;
  const rooms = state.classrooms || [];
  const active = rooms.filter((room) => room.status === "active").length;
  const maintenance = rooms.filter((room) => room.status === "maintenance").length;
  const capacity = rooms.reduce((sum, room) => sum + room.capacity, 0);
  holder.innerHTML = `
    <article class="stat-card stat-free stat-card-horizontal"><div class="stat-icon">${icon("building")}</div><div class="stat-body"><span class="stat-label">教室总数</span><div class="stat-value">${rooms.length}<small>间</small></div></div></article>
    <article class="stat-card stat-busy stat-card-horizontal"><div class="stat-icon">${icon("check")}</div><div class="stat-body"><span class="stat-label">开放中</span><div class="stat-value">${active}<small>间</small></div></div></article>
    <article class="stat-card stat-book stat-card-horizontal"><div class="stat-icon">${icon("users")}</div><div class="stat-body"><span class="stat-label">总容量</span><div class="stat-value">${capacity}<small>座</small></div></div></article>
    <article class="stat-card stat-muted stat-card-horizontal"><div class="stat-icon">${icon("settings")}</div><div class="stat-body"><span class="stat-label">维护中</span><div class="stat-value">${maintenance}<small>间</small></div></div></article>`;
}

function filteredClassrooms() {
  const rooms = state.classrooms || [];
  const filters = state.classroomFilters;
  return rooms.filter((room) => {
    if (filters.building && room.building !== filters.building) return false;
    if (filters.status !== "all" && room.status !== filters.status) return false;
    if (filters.q) {
      const text = `${room.name} ${room.building} ${room.room_no} ${room.room_type} ${room.equipment.join(" ")}`.toLowerCase();
      if (!text.includes(filters.q.toLowerCase())) return false;
    }
    return true;
  });
}

function renderClassroomGrid() {
  const holder = $("#classroom-grid");
  if (!holder) return;
  const rooms = filteredClassrooms();
  const count = $("#classroom-count");
  if (count) count.textContent = `共 ${(state.classrooms || []).length} 间教室 · 当前显示 ${rooms.length} 间`;

  if (!rooms.length) {
    holder.innerHTML = emptyState("building", "没有匹配的教室", "请调整筛选条件，或新增一间教室。");
    return;
  }

  holder.innerHTML = rooms.map((room) => `
    <article class="classroom-admin-card ${room.status === "maintenance" ? "is-maintenance" : ""}">
      <div class="classroom-admin-head">
        <div class="room-icon">${icon("building")}</div>
        <div class="classroom-admin-title">
          <h3>${esc(room.name)}</h3>
          <p>${esc(room.building)} · ${esc(room.room_no)}</p>
        </div>
        <span class="status-pill ${room.status === "active" ? "status-free" : "status-maintenance"}"><i></i>${room.status === "active" ? "开放中" : "维护中"}</span>
      </div>
      <div class="classroom-admin-facts">
        <div><span>类型</span><strong>${esc(room.room_type)}</strong></div>
        <div><span>容量</span><strong>${room.capacity} 人</strong></div>
      </div>
      <div class="classroom-tags">
        ${room.equipment.length ? room.equipment.map((item) => `<span>${esc(item)}</span>`).join("") : "<span>暂无设备信息</span>"}
      </div>
      <div class="classroom-admin-foot">
        <span>ROOM ${String(room.id).padStart(2, "0")}</span>
        <button type="button" class="btn btn-ghost btn-sm" data-edit-room="${room.id}">${icon("edit")}编辑档案</button>
      </div>
    </article>`).join("");

  holder.querySelectorAll("[data-edit-room]").forEach((button) => {
    button.addEventListener("click", () => {
      const room = (state.classrooms || []).find((item) => item.id === Number(button.dataset.editRoom));
      if (room) openClassroomModal(room);
    });
  });
}

function openClassroomModal(room = null) {
  const editing = Boolean(room);
  const values = room || {
    name: "",
    building: "",
    room_no: "",
    capacity: 60,
    room_type: "多媒体教室",
    equipment: [],
    status: "active",
  };
  const roomTypes = Array.from(new Set([...(state.meta.room_types || []), "普通教室", "多媒体教室", "研讨室", "机房", "阶梯教室", "智慧教室"]));
  const body = `
    <form id="classroom-form" class="stack-form" novalidate>
      <div class="form-error" role="alert"></div>
      <div class="form-grid two">
        <label class="field">
          <span>教室名称</span>
          <input type="text" name="name" maxlength="40" value="${esc(values.name)}" placeholder="例如 综合楼 A101" autofocus required>
        </label>
        <label class="field">
          <span>所属楼栋</span>
          <input type="text" name="building" maxlength="30" value="${esc(values.building)}" placeholder="例如 综合楼" required>
        </label>
        <label class="field">
          <span>房间号</span>
          <input type="text" name="room_no" maxlength="20" value="${esc(values.room_no)}" placeholder="例如 A101" required>
        </label>
        <label class="field">
          <span>容纳人数</span>
          <input type="number" name="capacity" min="1" max="2000" value="${values.capacity}" required>
        </label>
        <label class="field">
          <span>教室类型</span>
          <input type="text" name="room_type" maxlength="30" value="${esc(values.room_type)}" list="room-type-options" required>
          <datalist id="room-type-options">${roomTypes.map((type) => `<option value="${esc(type)}"></option>`).join("")}</datalist>
        </label>
        <label class="field">
          <span>开放状态</span>
          <select name="status" required>
            <option value="active" ${values.status === "active" ? "selected" : ""}>开放中</option>
            <option value="maintenance" ${values.status === "maintenance" ? "selected" : ""}>维护中</option>
          </select>
        </label>
      </div>
      <label class="field">
        <span>教室设备</span>
        <input type="text" name="equipment" maxlength="200" value="${esc((values.equipment || []).join(","))}" placeholder="用英文逗号分隔，例如 投影,音响,空调">
        <small class="field-hint">设备信息会显示在教室总览卡片中。</small>
      </label>
      <div class="form-note">${icon("alert")}切换为维护中后，新的借用会被阻止，已生效的借用不会自动取消，请提前通知相关教师。</div>
    </form>`;

  const modal = openModal({
    title: editing ? "编辑教室" : "新增教室",
    subtitle: editing ? `${room.name} · ${room.building}` : "将教室加入可用教学空间",
    size: "modal-md",
    body,
    footer: `
      <button type="button" class="btn btn-ghost" data-cancel>取消</button>
      <button type="submit" class="btn btn-primary" form="classroom-form" data-submit>${icon("check")}${editing ? "保存修改" : "创建教室"}</button>`,
  });

  const form = modal.element.querySelector("#classroom-form");
  const submit = modal.element.querySelector("[data-submit]");
  modal.element.querySelector("[data-cancel]")?.addEventListener("click", () => modal.close());
  form?.addEventListener("input", () => clearFormError(form));

  form?.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearFormError(form);
    const data = Object.fromEntries(new FormData(form).entries());
    if (!data.name.trim() || !data.building.trim() || !data.room_no.trim() || !data.room_type.trim()) {
      formError(form, "请完整填写教室名称、楼栋、房间号和类型");
      return;
    }
    const capacity = Number(data.capacity);
    if (!Number.isFinite(capacity) || capacity <= 0) {
      formError(form, "容纳人数必须大于 0");
      return;
    }
    setButtonLoading(submit, true, "保存中...");
    try {
      const endpoint = editing ? `/classrooms/${room.id}` : "/classrooms";
      await api(endpoint, {
        method: editing ? "PUT" : "POST",
        body: {
          name: data.name.trim(),
          building: data.building.trim(),
          room_no: data.room_no.trim(),
          capacity,
          room_type: data.room_type.trim(),
          equipment: data.equipment.trim(),
          status: data.status,
        },
      });
      modal.close(true);
      toast(editing ? "教室档案已更新" : "教室已创建");
      await loadMeta();
      const content = $("#page-content");
      if (content && state.page === "classrooms") {
        await renderClassroomsPage(content);
      }
    } catch (error) {
      formError(form, error.message);
      setButtonLoading(submit, false);
    }
  });
}
